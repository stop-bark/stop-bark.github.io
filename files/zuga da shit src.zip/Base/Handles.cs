﻿// Decompiled with JetBrains decompiler
// Type: GTBit_Beta.Base.Handles
// Assembly: Zuga, Version=69.69.69.69, Culture=neutral, PublicKeyToken=null
// MVID: 67EB7C18-B003-46F1-ADEB-DA1D25C66E9D
// Assembly location: C:\Users\dzint\Downloads\Zuga.exe

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;

namespace GTBit_Beta.Base
{
  public static class Handles
  {
    private const uint PROCESS_DUP_HANDLE = 64;
    private const uint PROCESS_QUERY_INFORMATION = 1024;
    private const uint PROCESS_VM_READ = 16;
    private const int MAX_PATH = 260;
    private static int lastSizeUsed = 65536;
    private const int SystemExtendedHandleInformation = 64;
    private static readonly string NETWORK_PREFIX = "\\Device\\Mup\\";

    [DllImport("ntdll.dll")]
    private static extern Handles.NT_STATUS NtDuplicateObject(
      IntPtr SourceProcessHandle,
      IntPtr SourceHandle,
      IntPtr TargetProcessHandle,
      out IntPtr TargetHandle,
      uint DesiredAccess,
      uint Attributes,
      uint Options);

    [DllImport("ntdll.dll")]
    private static extern Handles.NT_STATUS NtQueryObject(
      IntPtr ObjectHandle,
      Handles.ObjectInformationClass ObjectInformationClass,
      IntPtr ObjectInformation,
      int ObjectInformationLength,
      out int returnLength);

    [DllImport("kernel32.dll", SetLastError = true)]
    public static extern uint QueryDosDevice(
      string lpDeviceName,
      StringBuilder lpTargetPath,
      int ucchMax);

    [DllImport("kernel32.dll")]
    private static extern int CloseHandle(IntPtr hObject);

    [DllImport("kernel32.dll")]
    private static extern IntPtr OpenProcess(
      Handles.ProcessAccessFlags dwDesiredAccess,
      [MarshalAs(UnmanagedType.Bool)] bool bInheritHandle,
      int dwProcessId);

    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool DuplicateHandle(
      IntPtr hSourceProcessHandle,
      IntPtr hSourceHandle,
      IntPtr hTargetProcessHandle,
      out IntPtr lpTargetHandle,
      uint dwDesiredAccess,
      [MarshalAs(UnmanagedType.Bool)] bool bInheritHandle,
      Handles.DuplicateOptions dwOptions);

    public static bool CloseHandleEx(int pid, IntPtr handle)
    {
      IntPtr num1 = Handles.OpenProcess(Handles.ProcessAccessFlags.DupHandle, false, pid);
      IntPtr lpTargetHandle = IntPtr.Zero;
      int num2 = Handles.DuplicateHandle(num1, handle, IntPtr.Zero, out lpTargetHandle, 0U, false, Handles.DuplicateOptions.DUPLICATE_CLOSE_SOURCE) ? 1 : 0;
      Handles.CloseHandle(num1);
      return num2 != 0;
    }

    public static IEnumerable<HandleInfo> EnumProcessHandles(int pid)
    {
      using (Process.GetProcessById(pid))
      {
        IntPtr hProcess = Handles.OpenProcess(Handles.ProcessAccessFlags.DupHandle, false, pid);
        foreach (Handles._SYSTEM_HANDLE_TABLE_ENTRY_INFO_EX enumHandle in Handles.EnumHandles(pid))
        {
          IntPtr hObj = IntPtr.Zero;
          string str1 = (string) null;
          string str2 = (string) null;
          try
          {
            enumHandle.HandleValue.ToInt32();
            if (Handles.NT_SUCCESS(Handles.NtDuplicateObject(hProcess, enumHandle.HandleValue, Process.GetCurrentProcess().Handle, out hObj, 0U, 0U, 0U)))
            {
              using (Handles.NtObject ntObject = new Handles.NtObject(hObj, Handles.ObjectInformationClass.ObjectTypeInformation, typeof (Handles.OBJECT_TYPE_INFORMATION)))
              {
                try
                {
                  str1 = Handles.ObjectTypeInformationFromBuffer(ntObject.Buffer).Name.ToString();
                }
                catch (Exception ex)
                {
                }
              }
              if (str1.Equals("File"))
              {
                if (enumHandle.GrantedAccess == 1180063U || enumHandle.GrantedAccess == 1704351U || (enumHandle.GrantedAccess == 1048576U || enumHandle.GrantedAccess == 1441793U) || (enumHandle.GrantedAccess == 1048577U || enumHandle.GrantedAccess == 1048608U))
                  goto label_22;
              }
              else
              {
                using (Handles.NtObject ntObject = new Handles.NtObject(hObj, Handles.ObjectInformationClass.ObjectNameInformation, typeof (Handles.OBJECT_NAME_INFORMATION)))
                {
                  try
                  {
                    Handles.OBJECT_NAME_INFORMATION objectNameInformation = Handles.ObjectNameInformationFromBuffer(ntObject.Buffer);
                    str2 = !str1.Equals("File") ? objectNameInformation.Name.ToString() : Handles.GetRegularFileNameFromDevice(objectNameInformation.Name.ToString());
                  }
                  catch (Exception ex)
                  {
                  }
                }
              }
              yield return new HandleInfo()
              {
                Handle = enumHandle.HandleValue,
                Type = str1,
                Name = str2,
                CreatorBackTraceIndex = enumHandle.CreatorBackTraceIndex,
                GrantedAccess = enumHandle.GrantedAccess,
                HandleAttributes = enumHandle.HandleAttributes,
                Object = enumHandle.Object,
                ObjectTypeIndex = enumHandle.ObjectTypeIndex,
                Reserved = enumHandle.Reserved,
                UniqueProcessId = enumHandle.UniqueProcessId
              };
              continue;
            }
label_22:;
          }
          finally
          {
            Handles.CloseHandle(hObj);
          }
        }
        Handles.CloseHandle(hProcess);
      }
    }

    private static unsafe Handles.OBJECT_TYPE_INFORMATION ObjectTypeInformationFromBuffer(
      IntPtr buffer)
    {
      return *(Handles.OBJECT_TYPE_INFORMATION*) buffer.ToPointer();
    }

    private static unsafe Handles.OBJECT_NAME_INFORMATION ObjectNameInformationFromBuffer(
      IntPtr buffer)
    {
      return *(Handles.OBJECT_NAME_INFORMATION*) buffer.ToPointer();
    }

    private static unsafe Handles._SYSTEM_HANDLE_TABLE_ENTRY_INFO_EX SystemExtendedHandleFromPtr(
      IntPtr ptr,
      int offset)
    {
      return *(Handles._SYSTEM_HANDLE_TABLE_ENTRY_INFO_EX*) ((IntPtr) ptr.ToPointer() + offset);
    }

    private static IEnumerable<Handles._SYSTEM_HANDLE_TABLE_ENTRY_INFO_EX> EnumHandles(
      int processId)
    {
      int num = Handles.lastSizeUsed;
      IntPtr buffer = Marshal.AllocCoTaskMem(num);
      try
      {
        int ReturnLength;
        for (; Handles.NtQuerySystemInformation(64, buffer, num, out ReturnLength) == Handles.NT_STATUS.INFO_LENGTH_MISMATCH; buffer = Marshal.ReAllocCoTaskMem(buffer, num))
          num = ReturnLength;
        if (Handles.lastSizeUsed < num)
          Handles.lastSizeUsed = num;
        int entrySize = Marshal.SizeOf(typeof (Handles._SYSTEM_HANDLE_TABLE_ENTRY_INFO_EX));
        int offset = Marshal.SizeOf(typeof (IntPtr)) * 2;
        int handleCount = Marshal.ReadInt32(buffer);
        for (int i = 0; i < handleCount; ++i)
        {
          Handles._SYSTEM_HANDLE_TABLE_ENTRY_INFO_EX tableEntryInfoEx = Handles.SystemExtendedHandleFromPtr(buffer, offset + entrySize * i);
          if (!(tableEntryInfoEx.UniqueProcessId != new IntPtr(processId)))
            yield return tableEntryInfoEx;
        }
      }
      finally
      {
        if (buffer != IntPtr.Zero)
          Marshal.FreeCoTaskMem(buffer);
      }
    }

    [DllImport("ntdll.dll")]
    private static extern Handles.NT_STATUS NtQuerySystemInformation(
      int SystemInformationClass,
      IntPtr SystemInformation,
      int SystemInformationLength,
      out int ReturnLength);

    private static bool NT_SUCCESS(Handles.NT_STATUS status) => (status & (Handles.NT_STATUS) 2147483648) == Handles.NT_STATUS.SUCCESS;

    private static string GetRegularFileNameFromDevice(string strRawName)
    {
      if (strRawName.StartsWith(Handles.NETWORK_PREFIX))
        return "\\\\" + strRawName.Substring(Handles.NETWORK_PREFIX.Length);
      string str1 = strRawName;
      foreach (string logicalDrive in Environment.GetLogicalDrives())
      {
        string lpDeviceName = logicalDrive.Substring(0, 2);
        StringBuilder lpTargetPath = new StringBuilder(260);
        if (Handles.QueryDosDevice(lpDeviceName, lpTargetPath, 260) == 0U)
          return strRawName;
        string str2 = lpTargetPath.ToString();
        if (str1.StartsWith(str2))
        {
          str1 = lpDeviceName + str1.Substring(str2.Length);
          break;
        }
      }
      return str1;
    }

    [Flags]
    private enum DuplicateOptions : uint
    {
      DUPLICATE_CLOSE_SOURCE = 1,
      DUPLICATE_SAME_ACCESS = 2,
    }

    public enum ProcessAccessFlags : uint
    {
      Terminate = 1,
      CreateThread = 2,
      VMOperation = 8,
      PROCESS_VM_READ = 16, // 0x00000010
      VMWrite = 32, // 0x00000020
      DupHandle = 64, // 0x00000040
      SetInformation = 512, // 0x00000200
      QueryInformation = 1024, // 0x00000400
      Synchronize = 1048576, // 0x00100000
      All = 2035711, // 0x001F0FFF
    }

    private class NtObject : IDisposable
    {
      public NtObject(IntPtr hObj, Handles.ObjectInformationClass infoClass, Type type) => this.Init(hObj, infoClass, Marshal.SizeOf(type));

      public NtObject(IntPtr hObj, Handles.ObjectInformationClass infoClass, int estimatedSize) => this.Init(hObj, infoClass, estimatedSize);

      public void Init(IntPtr hObj, Handles.ObjectInformationClass infoClass, int estimatedSize)
      {
        this.Close();
        this.Buffer = Handles.NtObject.Query(hObj, infoClass, estimatedSize);
      }

      public void Close()
      {
        if (!(this.Buffer != IntPtr.Zero))
          return;
        Marshal.FreeCoTaskMem(this.Buffer);
        this.Buffer = IntPtr.Zero;
      }

      public void Dispose() => this.Close();

      public IntPtr Buffer { get; private set; }

      public static IntPtr Query(
        IntPtr hObj,
        Handles.ObjectInformationClass infoClass,
        int estimatedSize)
      {
        int num1 = estimatedSize;
        IntPtr num2 = Marshal.AllocCoTaskMem(num1);
        int returnLength = 0;
        while (true)
        {
          Handles.NT_STATUS status = Handles.NtQueryObject(hObj, infoClass, num2, num1, out returnLength);
          if (!Handles.NT_SUCCESS(status))
          {
            if (status == Handles.NT_STATUS.INFO_LENGTH_MISMATCH || status == Handles.NT_STATUS.BUFFER_OVERFLOW)
            {
              num2 = Marshal.ReAllocCoTaskMem(num2, returnLength);
              num1 = returnLength;
            }
            else
              goto label_5;
          }
          else
            break;
        }
        return num2;
label_5:
        Marshal.FreeCoTaskMem(num2);
        return IntPtr.Zero;
      }
    }

    private struct _SYSTEM_HANDLE_TABLE_ENTRY_INFO_EX
    {
      public IntPtr Object;
      public IntPtr UniqueProcessId;
      public IntPtr HandleValue;
      public uint GrantedAccess;
      public ushort CreatorBackTraceIndex;
      public ushort ObjectTypeIndex;
      public uint HandleAttributes;
      public uint Reserved;
    }

    private enum NT_STATUS : uint
    {
      SUCCESS = 0,
      BUFFER_OVERFLOW = 2147483653, // 0x80000005
      INFO_LENGTH_MISMATCH = 3221225476, // 0xC0000004
    }

    private enum ObjectInformationClass
    {
      ObjectBasicInformation,
      ObjectNameInformation,
      ObjectTypeInformation,
      ObjectAllTypesInformation,
      ObjectHandleInformation,
    }

    private struct OBJECT_NAME_INFORMATION
    {
      public Handles.UNICODE_STRING Name;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    private struct UNICODE_STRING
    {
      private IntPtr reserved;
      public IntPtr Buffer;

      public ushort Length => (ushort) ((ulong) this.reserved.ToInt64() & (ulong) ushort.MaxValue);

      public ushort MaximumLength => (ushort) (this.reserved.ToInt64() >> 16);

      public override string ToString() => this.Buffer == IntPtr.Zero ? "" : Marshal.PtrToStringUni(this.Buffer, this.Wcslen());

      public unsafe int Wcslen()
      {
        ushort* pointer = (ushort*) this.Buffer.ToPointer();
        for (ushort index = 0; (int) index < (int) this.Length; ++index)
        {
          if (pointer[index] == (ushort) 0)
            return (int) index;
        }
        return (int) this.Length;
      }
    }

    private struct GENERIC_MAPPING
    {
      public int GenericRead;
      public int GenericWrite;
      public int GenericExecute;
      public int GenericAll;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    private struct OBJECT_TYPE_INFORMATION
    {
      public Handles.UNICODE_STRING Name;
      public uint TotalNumberOfObjects;
      public uint TotalNumberOfHandles;
      public uint TotalPagedPoolUsage;
      public uint TotalNonPagedPoolUsage;
      public uint TotalNamePoolUsage;
      public uint TotalHandleTableUsage;
      public uint HighWaterNumberOfObjects;
      public uint HighWaterNumberOfHandles;
      public uint HighWaterPagedPoolUsage;
      public uint HighWaterNonPagedPoolUsage;
      public uint HighWaterNamePoolUsage;
      public uint HighWaterHandleTableUsage;
      public uint InvalidAttributes;
      public Handles.GENERIC_MAPPING GenericMapping;
      public uint ValidAccess;
      public byte SecurityRequired;
      public byte MaintainHandleCount;
      public ushort MaintainTypeList;
      public int PoolType;
      public int PagedPoolUsage;
      public int NonPagedPoolUsage;
    }
  }
}
