﻿// Decompiled with JetBrains decompiler
// Type: GTBit_Beta.Base.Imports
// Assembly: Zuga, Version=69.69.69.69, Culture=neutral, PublicKeyToken=null
// MVID: 67EB7C18-B003-46F1-ADEB-DA1D25C66E9D
// Assembly location: C:\Users\dzint\Downloads\Zuga.exe

using System;
using System.Collections;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Text;

namespace GTBit_Beta.Base
{
  public class Imports
  {
    [DllImport("user32.dll")]
    public static extern bool RegisterHotKey(IntPtr hWnd, int id, int fsModifiers, int vk);

    [DllImport("user32.dll")]
    public static extern bool UnregisterHotKey(IntPtr hWnd, int id);

    [DllImport("user32.dll")]
    public static extern IntPtr GetForegroundWindow();

    [DllImport("user32.dll")]
    public static extern int GetWindowText(IntPtr hWnd, StringBuilder text, int count);

    public static string GetActiveWindowTitle()
    {
      StringBuilder text = new StringBuilder(256);
      return Imports.GetWindowText(Imports.GetForegroundWindow(), text, 256) > 0 ? text.ToString() : (string) null;
    }

    [DllImport("User32.dll")]
    public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, [MarshalAs(UnmanagedType.LPStr)] string lParam);

    [DllImport("User32.dll")]
    public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);

    public static int Coordinate(int X, int Y) => Y << 16 | X & (int) ushort.MaxValue;

    public static int Coordinate(Point point) => point.Y << 16 | point.X & (int) ushort.MaxValue;

    [DllImport("user32.dll")]
    public static extern int GetWindowRect(IntPtr hwnd, out Imports.RECT lpRect);

    [DllImport("user32.dll")]
    public static extern bool ClientToScreen(IntPtr hWnd, out Point lpPoint);

    [DllImport("user32.dll")]
    public static extern bool GetClientRect(IntPtr hWnd, out Imports.RECT lpRect);

    [DllImport("user32.dll")]
    public static extern bool SetForegroundWindow(IntPtr hWnd);

    [DllImport("user32.dll")]
    public static extern IntPtr FindWindow(string lpClassName, string lpWindowName);

    public static IntPtr GetWindowHandle(string title) => Imports.FindWindow((string) null, title);

    [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
    public static extern bool SetWindowText(IntPtr hwnd, string lpString);

    [DllImport("user32.dll", SetLastError = true)]
    public static extern bool MoveWindow(
      IntPtr hWnd,
      int X,
      int Y,
      int nWidth,
      int nHeight,
      bool bRepaint);

    [DllImport("user32.dll", SetLastError = true)]
    public static extern IntPtr SetParent(IntPtr hWndChild, IntPtr hWndNewParent);

    [DllImport("kernel32.dll")]
    private static extern IntPtr OpenThread(
      Imports.ThreadAccess dwDesiredAccess,
      bool bInheritHandle,
      uint dwThreadId);

    [DllImport("kernel32.dll")]
    private static extern uint SuspendThread(IntPtr hThread);

    [DllImport("kernel32.dll")]
    private static extern int ResumeThread(IntPtr hThread);

    [DllImport("kernel32", CharSet = CharSet.Auto, SetLastError = true)]
    private static extern bool CloseHandle(IntPtr handle);

    public static void SuspendProcess(int pid)
    {
      Process processById = Process.GetProcessById(pid);
      if (processById.ProcessName == string.Empty)
        return;
      foreach (ProcessThread thread in (ReadOnlyCollectionBase) processById.Threads)
      {
        IntPtr num1 = Imports.OpenThread(Imports.ThreadAccess.SUSPEND_RESUME, false, (uint) thread.Id);
        if (!(num1 == IntPtr.Zero))
        {
          int num2 = (int) Imports.SuspendThread(num1);
          Imports.CloseHandle(num1);
        }
      }
    }

    public static void ResumeProcess(int pid)
    {
      Process processById = Process.GetProcessById(pid);
      if (processById.ProcessName == string.Empty)
        return;
      foreach (ProcessThread thread in (ReadOnlyCollectionBase) processById.Threads)
      {
        IntPtr num = Imports.OpenThread(Imports.ThreadAccess.SUSPEND_RESUME, false, (uint) thread.Id);
        if (!(num == IntPtr.Zero))
        {
          do
            ;
          while (Imports.ResumeThread(num) > 0);
          Imports.CloseHandle(num);
        }
      }
    }

    public struct RECT
    {
      public int Left;
      public int Top;
      public int Right;
      public int Bottom;
    }

    [Flags]
    public enum ThreadAccess
    {
      TERMINATE = 1,
      SUSPEND_RESUME = 2,
      GET_CONTEXT = 8,
      SET_CONTEXT = 16, // 0x00000010
      SET_INFORMATION = 32, // 0x00000020
      QUERY_INFORMATION = 64, // 0x00000040
      SET_THREAD_TOKEN = 128, // 0x00000080
      IMPERSONATE = 256, // 0x00000100
      DIRECT_IMPERSONATION = 512, // 0x00000200
    }
  }
}
