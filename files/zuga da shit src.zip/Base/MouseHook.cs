﻿// Decompiled with JetBrains decompiler
// Type: GTBit_Beta.Base.MouseHook
// Assembly: Zuga, Version=69.69.69.69, Culture=neutral, PublicKeyToken=null
// MVID: 67EB7C18-B003-46F1-ADEB-DA1D25C66E9D
// Assembly location: C:\Users\dzint\Downloads\Zuga.exe

using System;
using System.Diagnostics;
using System.Runtime.InteropServices;

namespace GTBit_Beta.Base
{
  public class MouseHook
  {
    private MouseHook.MouseHookHandler hookHandler;
    private IntPtr hookID = IntPtr.Zero;

    public event MouseHook.MouseHookCallback MouseButtonDown;

    public void Install()
    {
      this.hookHandler = new MouseHook.MouseHookHandler(this.HookFunc);
      this.hookID = this.SetHook(this.hookHandler);
    }

    public void Uninstall()
    {
      if (this.hookID == IntPtr.Zero)
        return;
      MouseHook.UnhookWindowsHookEx(this.hookID);
      this.hookID = IntPtr.Zero;
    }

    ~MouseHook() => this.Uninstall();

    private IntPtr SetHook(MouseHook.MouseHookHandler proc)
    {
      using (ProcessModule mainModule = Process.GetCurrentProcess().MainModule)
        return MouseHook.SetWindowsHookEx(14, proc, MouseHook.GetModuleHandle(mainModule.ModuleName), 0U);
    }

    private IntPtr HookFunc(int nCode, IntPtr wParam, IntPtr lParam)
    {
      if (nCode >= 0 && 513 == (int) wParam && this.MouseButtonDown != null)
        this.MouseButtonDown((MouseHook.MSLLHOOKSTRUCT) Marshal.PtrToStructure(lParam, typeof (MouseHook.MSLLHOOKSTRUCT)));
      return MouseHook.CallNextHookEx(this.hookID, nCode, wParam, lParam);
    }

    [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
    private static extern IntPtr SetWindowsHookEx(
      int idHook,
      MouseHook.MouseHookHandler lpfn,
      IntPtr hMod,
      uint dwThreadId);

    [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    public static extern bool UnhookWindowsHookEx(IntPtr hhk);

    [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
    private static extern IntPtr CallNextHookEx(
      IntPtr hhk,
      int nCode,
      IntPtr wParam,
      IntPtr lParam);

    [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
    private static extern IntPtr GetModuleHandle(string lpModuleName);

    private delegate IntPtr MouseHookHandler(int nCode, IntPtr wParam, IntPtr lParam);

    public delegate void MouseHookCallback(MouseHook.MSLLHOOKSTRUCT mouseStruct);

    private enum MouseMessages
    {
      WM_LBUTTONDOWN = 513, // 0x00000201
    }

    public struct POINT
    {
      public int x;
      public int y;
    }

    public struct MSLLHOOKSTRUCT
    {
      public MouseHook.POINT pt;
      public uint mouseData;
      public uint flags;
      public uint time;
      public IntPtr dwExtraInfo;
    }
  }
}
