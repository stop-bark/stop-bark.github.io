﻿// Decompiled with JetBrains decompiler
// Type: GTBit_Beta.Base.IniFile
// Assembly: Zuga, Version=69.69.69.69, Culture=neutral, PublicKeyToken=null
// MVID: 67EB7C18-B003-46F1-ADEB-DA1D25C66E9D
// Assembly location: C:\Users\dzint\Downloads\Zuga.exe

using System.IO;
using System.Runtime.InteropServices;
using System.Text;

namespace GTBit_Beta.Base
{
  public class IniFile
  {
    private string Path;
    private string App = "GTBit Beta";

    [DllImport("kernel32", CharSet = CharSet.Unicode)]
    private static extern long WritePrivateProfileString(
      string Section,
      string Key,
      string Value,
      string FilePath);

    [DllImport("kernel32", CharSet = CharSet.Unicode)]
    private static extern int GetPrivateProfileString(
      string Section,
      string Key,
      string Default,
      StringBuilder RetVal,
      int Size,
      string FilePath);

    public IniFile(string IniPath = null) => this.Path = new FileInfo(IniPath ?? this.App + ".ini").FullName.ToString();

    public string Read(string Key, string Section = null)
    {
      StringBuilder RetVal = new StringBuilder((int) byte.MaxValue);
      IniFile.GetPrivateProfileString(Section ?? this.App, Key, "", RetVal, (int) byte.MaxValue, this.Path);
      return RetVal.ToString();
    }

    public void Write(string Key, string Value, string Section = null) => IniFile.WritePrivateProfileString(Section ?? this.App, Key, Value, this.Path);
  }
}
