﻿// Decompiled with JetBrains decompiler
// Type: GTBit_Beta.Base.ListViewSorter
// Assembly: Zuga, Version=69.69.69.69, Culture=neutral, PublicKeyToken=null
// MVID: 67EB7C18-B003-46F1-ADEB-DA1D25C66E9D
// Assembly location: C:\Users\dzint\Downloads\Zuga.exe

using System.Collections;
using System.Windows.Forms;

namespace GTBit_Beta.Base
{
  public class ListViewSorter : IComparer
  {
    private int Column;
    private int LastColumn;

    public int Compare(object o1, object o2)
    {
      if (!(o1 is ListViewItem) || !(o2 is ListViewItem))
        return 0;
      ListViewItem listViewItem = (ListViewItem) o2;
      string text1 = listViewItem.SubItems[this.ByColumn].Text;
      string text2 = ((ListViewItem) o1).SubItems[this.ByColumn].Text;
      int num = listViewItem.ListView.Sorting != SortOrder.Ascending ? string.Compare(text2, text1) : string.Compare(text1, text2);
      this.LastSort = this.ByColumn;
      return num;
    }

    public int ByColumn
    {
      get => this.Column;
      set => this.Column = value;
    }

    public int LastSort
    {
      get => this.LastColumn;
      set => this.LastColumn = value;
    }
  }
}
