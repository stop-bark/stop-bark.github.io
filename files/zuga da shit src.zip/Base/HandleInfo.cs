﻿// Decompiled with JetBrains decompiler
// Type: GTBit_Beta.Base.HandleInfo
// Assembly: Zuga, Version=69.69.69.69, Culture=neutral, PublicKeyToken=null
// MVID: 67EB7C18-B003-46F1-ADEB-DA1D25C66E9D
// Assembly location: C:\Users\dzint\Downloads\Zuga.exe

using System;

namespace GTBit_Beta.Base
{
  public class HandleInfo
  {
    public IntPtr Handle { get; set; }

    public string Type { get; set; }

    public string Name { get; set; }

    public IntPtr Object { get; set; }

    public IntPtr UniqueProcessId { get; set; }

    public uint GrantedAccess { get; set; }

    public ushort CreatorBackTraceIndex { get; set; }

    public ushort ObjectTypeIndex { get; set; }

    public uint HandleAttributes { get; set; }

    public uint Reserved { get; set; }
  }
}
