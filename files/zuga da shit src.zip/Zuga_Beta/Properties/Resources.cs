﻿// Decompiled with JetBrains decompiler
// Type: Zuga_Beta.Properties.Resources
// Assembly: Zuga, Version=69.69.69.69, Culture=neutral, PublicKeyToken=null
// MVID: 67EB7C18-B003-46F1-ADEB-DA1D25C66E9D
// Assembly location: C:\Users\dzint\Downloads\Zuga.exe

using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace Zuga_Beta.Properties
{
  [GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "16.0.0.0")]
  [DebuggerNonUserCode]
  [CompilerGenerated]
  internal class Resources
  {
    private static ResourceManager resourceMan;
    private static CultureInfo resourceCulture;

    internal Resources()
    {
    }

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static ResourceManager ResourceManager
    {
      get
      {
        if (Zuga_Beta.Properties.Resources.resourceMan == null)
          Zuga_Beta.Properties.Resources.resourceMan = new ResourceManager("Zuga_Beta.Properties.Resources", typeof (Zuga_Beta.Properties.Resources).Assembly);
        return Zuga_Beta.Properties.Resources.resourceMan;
      }
    }

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static CultureInfo Culture
    {
      get => Zuga_Beta.Properties.Resources.resourceCulture;
      set => Zuga_Beta.Properties.Resources.resourceCulture = value;
    }
  }
}
