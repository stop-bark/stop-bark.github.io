﻿// Decompiled with JetBrains decompiler
// Type: GTBit_Beta.MiniControl
// Assembly: Zuga, Version=69.69.69.69, Culture=neutral, PublicKeyToken=null
// MVID: 67EB7C18-B003-46F1-ADEB-DA1D25C66E9D
// Assembly location: C:\Users\dzint\Downloads\Zuga.exe

using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace GTBit_Beta
{
  public class MiniControl : Form
  {
    private MainForm ownerForm;
    private IContainer components;
    private Button MCbuttonRecord;
    private Button MCbuttonPlay;

    public MiniControl() => this.InitializeComponent();

    public event EventHandler RecordEvent;

    public event EventHandler PlayEvent;

    private void MiniControl_Load(object sender, EventArgs e)
    {
      this.ownerForm = (MainForm) this.Owner;
      this.SetDesktopLocation(0, 0);
      this.Size = new Size(this.Width, 35);
      this.Hide();
    }

    private Color getColor() => this.ownerForm.BackColor;

    public void updateStyle()
    {
      this.BackColor = this.getColor();
      if (this.MCbuttonRecord.Text == "Record")
        this.MCbuttonRecord.ForeColor = this.getColor();
      if (!(this.MCbuttonPlay.Text == "Play"))
        return;
      this.MCbuttonPlay.ForeColor = this.getColor();
    }

    public void updateButtons()
    {
      if (this.ownerForm.buttonRecord.Text == "Stop")
      {
        this.MCbuttonRecord.Text = "Stop";
        this.MCbuttonRecord.ForeColor = Color.White;
      }
      else
      {
        this.MCbuttonRecord.Text = "Record";
        this.MCbuttonRecord.ForeColor = this.getColor();
      }
      if (this.ownerForm.buttonPlay.Text == "Stop")
      {
        this.MCbuttonPlay.Text = "Stop";
        this.MCbuttonPlay.ForeColor = Color.White;
      }
      else
      {
        this.MCbuttonPlay.Text = "Play";
        this.MCbuttonPlay.ForeColor = this.getColor();
      }
    }

    private void Button1_Click(object sender, EventArgs e)
    {
      EventHandler recordEvent = this.RecordEvent;
      if (recordEvent != null)
        recordEvent((object) this, EventArgs.Empty);
      this.updateButtons();
    }

    private void Button2_Click(object sender, EventArgs e)
    {
      EventHandler playEvent = this.PlayEvent;
      if (playEvent != null)
        playEvent((object) this, EventArgs.Empty);
      this.updateButtons();
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof (MiniControl));
      this.MCbuttonRecord = new Button();
      this.MCbuttonPlay = new Button();
      this.SuspendLayout();
      this.MCbuttonRecord.BackColor = Color.FromArgb(10, 10, 10);
      this.MCbuttonRecord.FlatAppearance.BorderColor = Color.FromArgb(10, 10, 10);
      this.MCbuttonRecord.FlatAppearance.BorderSize = 0;
      this.MCbuttonRecord.FlatAppearance.MouseDownBackColor = Color.FromArgb(35, 35, 35);
      this.MCbuttonRecord.FlatAppearance.MouseOverBackColor = Color.FromArgb(35, 35, 35);
      this.MCbuttonRecord.FlatStyle = FlatStyle.Flat;
      this.MCbuttonRecord.Font = new Font("Caviar Dreams", 9.75f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.MCbuttonRecord.ForeColor = Color.Lime;
      this.MCbuttonRecord.Location = new Point(6, 0);
      this.MCbuttonRecord.Name = "MCbuttonRecord";
      this.MCbuttonRecord.Size = new Size(100, 35);
      this.MCbuttonRecord.TabIndex = 0;
      this.MCbuttonRecord.Text = "Record";
      this.MCbuttonRecord.UseVisualStyleBackColor = false;
      this.MCbuttonRecord.Click += new EventHandler(this.Button1_Click);
      this.MCbuttonPlay.BackColor = Color.FromArgb(10, 10, 10);
      this.MCbuttonPlay.FlatAppearance.BorderColor = Color.FromArgb(10, 10, 10);
      this.MCbuttonPlay.FlatAppearance.BorderSize = 0;
      this.MCbuttonPlay.FlatAppearance.MouseDownBackColor = Color.FromArgb(35, 35, 35);
      this.MCbuttonPlay.FlatAppearance.MouseOverBackColor = Color.FromArgb(35, 35, 35);
      this.MCbuttonPlay.FlatStyle = FlatStyle.Flat;
      this.MCbuttonPlay.Font = new Font("Caviar Dreams", 9.75f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.MCbuttonPlay.ForeColor = Color.Lime;
      this.MCbuttonPlay.Location = new Point(106, 0);
      this.MCbuttonPlay.Name = "MCbuttonPlay";
      this.MCbuttonPlay.Size = new Size(100, 35);
      this.MCbuttonPlay.TabIndex = 1;
      this.MCbuttonPlay.Text = "Play";
      this.MCbuttonPlay.UseVisualStyleBackColor = false;
      this.MCbuttonPlay.Click += new EventHandler(this.Button2_Click);
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.BackColor = Color.Lime;
      this.ClientSize = new Size(208, 35);
      this.Controls.Add((Control) this.MCbuttonPlay);
      this.Controls.Add((Control) this.MCbuttonRecord);
      this.FormBorderStyle = FormBorderStyle.None;
      this.Icon = (Icon) componentResourceManager.GetObject("$this.Icon");
      this.Name = nameof (MiniControl);
      this.ShowInTaskbar = false;
      this.Text = "GTBit Mini Control";
      this.TopMost = true;
      this.Load += new EventHandler(this.MiniControl_Load);
      this.ResumeLayout(false);
    }
  }
}
