﻿// Decompiled with JetBrains decompiler
// Type: GTBit_Beta.Program
// Assembly: Zuga, Version=69.69.69.69, Culture=neutral, PublicKeyToken=null
// MVID: 67EB7C18-B003-46F1-ADEB-DA1D25C66E9D
// Assembly location: C:\Users\dzint\Downloads\Zuga.exe

using System;
using System.Threading;
using System.Windows.Forms;

namespace GTBit_Beta
{
  internal static class Program
  {
    [STAThread]
    private static void Main()
    {
      Application.EnableVisualStyles();
      Application.SetCompatibleTextRenderingDefault(false);
      try
      {
        Mutex mutex = new Mutex(false, "GTBit_Beta_");
        try
        {
          if (mutex.WaitOne(0, false))
          {
            Application.Run((Form) new MainForm());
          }
          else
          {
            int num = (int) MessageBox.Show("An instance of the application is already running.", "GTBit Beta", MessageBoxButtons.OK, MessageBoxIcon.Hand);
          }
        }
        finally
        {
          mutex?.Close();
        }
      }
      catch (Exception ex)
      {
        int num = (int) MessageBox.Show("Unexpected error occured.\n\n" + ex.ToString(), "GTBit Beta", MessageBoxButtons.OK, MessageBoxIcon.Hand);
        Environment.Exit(0);
      }
    }
  }
}
