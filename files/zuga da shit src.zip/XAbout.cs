﻿// Decompiled with JetBrains decompiler
// Type: GTBit_Beta.XAbout
// Assembly: Zuga, Version=69.69.69.69, Culture=neutral, PublicKeyToken=null
// MVID: 67EB7C18-B003-46F1-ADEB-DA1D25C66E9D
// Assembly location: C:\Users\dzint\Downloads\Zuga.exe

using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

namespace GTBit_Beta
{
  public class XAbout : Form
  {
    private IContainer components;
    private Panel panel1;
    private Button button1;
    private Label label1;
    private Label content;
    private Button button2;

    public XAbout() => this.InitializeComponent();

    private void XAbout_Load(object sender, EventArgs e)
    {
    }

    private void Button1_Click(object sender, EventArgs e) => this.Close();

    private void Button2_Click(object sender, EventArgs e) => Process.Start("https://discord.gg/XerSgHesRH");

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof (XAbout));
      this.panel1 = new Panel();
      this.button2 = new Button();
      this.content = new Label();
      this.button1 = new Button();
      this.label1 = new Label();
      this.panel1.SuspendLayout();
      this.SuspendLayout();
      this.panel1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
      this.panel1.BackColor = Color.FromArgb(10, 10, 10);
      this.panel1.Controls.Add((Control) this.button2);
      this.panel1.Controls.Add((Control) this.content);
      this.panel1.Controls.Add((Control) this.button1);
      this.panel1.Controls.Add((Control) this.label1);
      this.panel1.Font = new Font("Caviar Dreams", 9.75f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.panel1.ForeColor = Color.SpringGreen;
      this.panel1.Location = new Point(0, 5);
      this.panel1.Name = "panel1";
      this.panel1.Size = new Size(270, 340);
      this.panel1.TabIndex = 3;
      this.button2.BackColor = Color.MediumSpringGreen;
      this.button2.FlatAppearance.BorderSize = 0;
      this.button2.FlatStyle = FlatStyle.Flat;
      this.button2.Font = new Font("Caviar Dreams", 9.75f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.button2.ForeColor = Color.Black;
      this.button2.Location = new Point(84, 270);
      this.button2.Name = "button2";
      this.button2.Size = new Size(80, 50);
      this.button2.TabIndex = 3;
      this.button2.Text = "Discord";
      this.button2.TextAlign = ContentAlignment.BottomLeft;
      this.button2.UseVisualStyleBackColor = false;
      this.button2.Click += new EventHandler(this.Button2_Click);
      this.content.AutoSize = true;
      this.content.Font = new Font("Caviar Dreams", 9.75f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.content.ForeColor = Color.SpringGreen;
      this.content.Location = new Point(21, 81);
      this.content.Name = "content";
      this.content.Size = new Size(229, 68);
      this.content.TabIndex = 2;
      this.content.Text = "Zuga is a great Auto/macro Clicker\r\nfor Growtopia.\r\n\r\nHotkeys: F1 (Record) F2 (Play)\r\n";
      this.button1.BackColor = Color.MediumSpringGreen;
      this.button1.FlatAppearance.BorderSize = 0;
      this.button1.FlatStyle = FlatStyle.Flat;
      this.button1.Font = new Font("Caviar Dreams", 9.75f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.button1.ForeColor = Color.Black;
      this.button1.Location = new Point(170, 270);
      this.button1.Name = "button1";
      this.button1.Size = new Size(80, 50);
      this.button1.TabIndex = 0;
      this.button1.Text = "OK";
      this.button1.TextAlign = ContentAlignment.BottomLeft;
      this.button1.UseVisualStyleBackColor = false;
      this.button1.Click += new EventHandler(this.Button1_Click);
      this.label1.AutoSize = true;
      this.label1.Font = new Font("Caviar Dreams", 20.25f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.label1.ForeColor = Color.SpringGreen;
      this.label1.Location = new Point(25, 25);
      this.label1.Name = "label1";
      this.label1.Size = new Size(93, 34);
      this.label1.TabIndex = 1;
      this.label1.Text = "About";
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.BackColor = Color.MediumSpringGreen;
      this.ClientSize = new Size(270, 350);
      this.ControlBox = false;
      this.Controls.Add((Control) this.panel1);
      this.ForeColor = Color.SpringGreen;
      this.FormBorderStyle = FormBorderStyle.None;
      this.Icon = (Icon) componentResourceManager.GetObject("$this.Icon");
      this.MaximizeBox = false;
      this.MinimizeBox = false;
      this.Name = nameof (XAbout);
      this.ShowIcon = false;
      this.ShowInTaskbar = false;
      this.StartPosition = FormStartPosition.CenterParent;
      this.Text = "GTBit Beta About";
      this.TopMost = true;
      this.Load += new EventHandler(this.XAbout_Load);
      this.panel1.ResumeLayout(false);
      this.panel1.PerformLayout();
      this.ResumeLayout(false);
    }
  }
}
