﻿// Decompiled with JetBrains decompiler
// Type: GTBit_Beta.Static.Workflow
// Assembly: Zuga, Version=69.69.69.69, Culture=neutral, PublicKeyToken=null
// MVID: 67EB7C18-B003-46F1-ADEB-DA1D25C66E9D
// Assembly location: C:\Users\dzint\Downloads\Zuga.exe

using GTBit_Beta.Base;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace GTBit_Beta.Static
{
  internal static class Workflow
  {
    public static bool Active;

    public static int PerformClicks(
      List<ListViewItem> windowList,
      List<ListViewItem> clickList,
      int interval)
    {
      Workflow.Active = true;
      while (Workflow.Active)
      {
        foreach (ListViewItem click in clickList)
        {
          if (!Workflow.Active)
            return 0;
          foreach (ListViewItem window in windowList)
          {
            if (!Workflow.Active)
              return 0;
            if (!(Imports.GetWindowHandle(window.SubItems[0].Text) != IntPtr.Zero))
              return 1;
            if (window.Checked)
            {
              Imports.SendMessage(Imports.GetWindowHandle(window.SubItems[0].Text), 513, 1, Imports.Coordinate(Workflow.ToPoint(click)));
              Imports.SendMessage(Imports.GetWindowHandle(window.SubItems[0].Text), 514, 1, Imports.Coordinate(Workflow.ToPoint(click)));
            }
          }
          Thread.Sleep(interval);
        }
      }
      return 0;
    }

    private static Point ToPoint(ListViewItem item) => new Point(int.Parse(item.SubItems[0].Text), int.Parse(item.SubItems[1].Text));
  }
}
