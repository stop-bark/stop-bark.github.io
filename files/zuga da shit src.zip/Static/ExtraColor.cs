﻿// Decompiled with JetBrains decompiler
// Type: GTBit_Beta.Static.ExtraColor
// Assembly: Zuga, Version=69.69.69.69, Culture=neutral, PublicKeyToken=null
// MVID: 67EB7C18-B003-46F1-ADEB-DA1D25C66E9D
// Assembly location: C:\Users\dzint\Downloads\Zuga.exe

using System.Collections.Generic;
using System.Drawing;

namespace GTBit_Beta.Static
{
  public static class ExtraColor
  {
    public static int current;
    public static List<Color> frenzyMode = new List<Color>()
    {
      Color.Red,
      Color.Orange,
      Color.Yellow,
      Color.Lime,
      Color.Cyan,
      Color.Fuchsia
    };
  }
}
