﻿using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Permissions;

[assembly: AssemblyTitle("GTBit Beta")]
[assembly: AssemblyDescription("Auto Clicker for Growtopia")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Arcane Growtopia")]
[assembly: AssemblyProduct("Arcane Growtopia GTBit Beta")]
[assembly: AssemblyCopyright("Arcane Growtopia 2020")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("73c3cacb-299e-48bc-a9b6-6381eb8acd1f")]
[assembly: AssemblyFileVersion("69.69.69.69")]
[assembly: AssemblyVersion("69.69.69.69")]
[assembly: SecurityPermission(SecurityAction.RequestMinimum, SkipVerification = true)]
