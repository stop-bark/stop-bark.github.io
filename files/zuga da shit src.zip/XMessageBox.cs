﻿// Decompiled with JetBrains decompiler
// Type: GTBit_Beta.XMessageBox
// Assembly: Zuga, Version=69.69.69.69, Culture=neutral, PublicKeyToken=null
// MVID: 67EB7C18-B003-46F1-ADEB-DA1D25C66E9D
// Assembly location: C:\Users\dzint\Downloads\Zuga.exe

using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace GTBit_Beta
{
  public class XMessageBox : Form
  {
    private IContainer components;
    private Button button1;
    private Panel panel1;
    private Label label1;
    public Label content;

    public XMessageBox() => this.InitializeComponent();

    private void XMessageBox_Load(object sender, EventArgs e)
    {
    }

    private void Button1_Click(object sender, EventArgs e) => this.Close();

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof (XMessageBox));
      this.button1 = new Button();
      this.content = new Label();
      this.panel1 = new Panel();
      this.label1 = new Label();
      this.panel1.SuspendLayout();
      this.SuspendLayout();
      this.button1.BackColor = Color.Crimson;
      this.button1.FlatAppearance.BorderSize = 0;
      this.button1.FlatStyle = FlatStyle.Flat;
      this.button1.Font = new Font("Caviar Dreams", 9.75f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.button1.ForeColor = Color.Black;
      this.button1.Location = new Point(170, 168);
      this.button1.Name = "button1";
      this.button1.Size = new Size(80, 50);
      this.button1.TabIndex = 0;
      this.button1.Text = "OK";
      this.button1.TextAlign = ContentAlignment.BottomLeft;
      this.button1.UseVisualStyleBackColor = false;
      this.button1.Click += new EventHandler(this.Button1_Click);
      this.content.AutoSize = true;
      this.content.Font = new Font("Caviar Dreams", 9.75f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.content.ForeColor = Color.Red;
      this.content.Location = new Point(25, 80);
      this.content.Name = "content";
      this.content.Size = new Size(115, 17);
      this.content.TabIndex = 1;
      this.content.Text = "Enter Text Noob !";
      this.panel1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
      this.panel1.BackColor = Color.FromArgb(10, 10, 10);
      this.panel1.Controls.Add((Control) this.label1);
      this.panel1.Controls.Add((Control) this.button1);
      this.panel1.Controls.Add((Control) this.content);
      this.panel1.Font = new Font("Microsoft Sans Serif", 8.25f);
      this.panel1.Location = new Point(0, 5);
      this.panel1.Name = "panel1";
      this.panel1.Size = new Size(270, 238);
      this.panel1.TabIndex = 2;
      this.label1.AutoSize = true;
      this.label1.Font = new Font("Caviar Dreams", 20.25f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.label1.ForeColor = Color.Red;
      this.label1.Location = new Point(25, 25);
      this.label1.Name = "label1";
      this.label1.Size = new Size(70, 34);
      this.label1.TabIndex = 2;
      this.label1.Text = "Hey!";
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.BackColor = Color.Crimson;
      this.ClientSize = new Size(270, 248);
      this.ControlBox = false;
      this.Controls.Add((Control) this.panel1);
      this.ForeColor = Color.Red;
      this.FormBorderStyle = FormBorderStyle.None;
      this.Icon = (Icon) componentResourceManager.GetObject("$this.Icon");
      this.MaximizeBox = false;
      this.MinimizeBox = false;
      this.Name = nameof (XMessageBox);
      this.ShowIcon = false;
      this.ShowInTaskbar = false;
      this.StartPosition = FormStartPosition.CenterParent;
      this.Text = "GTBit Beta MessageBox";
      this.TopMost = true;
      this.Load += new EventHandler(this.XMessageBox_Load);
      this.panel1.ResumeLayout(false);
      this.panel1.PerformLayout();
      this.ResumeLayout(false);
    }
  }
}
