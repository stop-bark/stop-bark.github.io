﻿// Decompiled with JetBrains decompiler
// Type: GTBit_Beta.MainForm
// Assembly: Zuga, Version=69.69.69.69, Culture=neutral, PublicKeyToken=null
// MVID: 67EB7C18-B003-46F1-ADEB-DA1D25C66E9D
// Assembly location: C:\Users\dzint\Downloads\Zuga.exe

using GTBit_Beta.Base;
using GTBit_Beta.Static;
using Microsoft.Win32;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Threading;
using System.Windows.Forms;

namespace GTBit_Beta
{
  public class MainForm : Form
  {
    private Mutex mutex;
    private MiniControl miniControl = new MiniControl();
    private MouseHook mouseHook = new MouseHook();
    private XMessageBox message = new XMessageBox();
    private XAbout about = new XAbout();
    private List<ListViewItem> windowList = new List<ListViewItem>();
    private List<ListViewItem> clickList = new List<ListViewItem>();
    private int ClickInterval = 200;
    private bool ShowMini;
    private bool Hotkeys;
    private Process primaryWindow;
    private int formX;
    private int formY;
    private bool formDrag;
    private int sliderX;
    private bool sliderDrag;
    private IContainer components;
    private Panel panelForm;
    private TabControl tabControl1;
    private Panel panelTabControl;
    private TabPage tabPage2;
    private TabPage tabPage3;
    private Button buttonLG;
    private Panel TabSelector;
    private Panel panelTabSelectorActive;
    private Button buttonTab1;
    private Button buttonTab2;
    private Button buttonTab3;
    private Panel panelWL;
    private Label labelWL;
    private ListView listView1;
    private ColumnHeader columnHeader1;
    private Panel panelWLH;
    private Button buttonClose;
    private Button buttonMinimize;
    private Panel panelML;
    private Panel panelMLH;
    private Label labelMLY;
    private Label labelMLX;
    private ListView listView2;
    private ColumnHeader columnHeader2;
    private ColumnHeader columnHeader3;
    private Label labelCI;
    private ComboBox comboBoxColor;
    private Label labelFC;
    private Button buttonAbout;
    private Panel panelTrackBar2;
    private ContextMenuStrip Menu1;
    private ToolStripMenuItem closeToolStripMenuItem;
    private ToolStripMenuItem closeAllToolStripMenuItem;
    private ContextMenuStrip Menu2;
    private ToolStripMenuItem removeToolStripMenuItem;
    private ToolStripMenuItem clearListToolStripMenuItem;
    private Panel panelTrackBar;
    private Label labelSMC;
    private Panel panelSMC;
    private Button TrackBarSlider;
    private Button checkBoxSMC;
    public Button buttonPlay;
    public Button buttonRecord;
    private Label labelLogo;
    private Label labelTM;
    private Panel panelTM;
    private Button checkBoxTM;
    private System.Windows.Forms.Timer FrenzyMode;
    private ToolStripMenuItem setAsPrimaryToolStripMenuItem;
    private Label labelHK;
    private Panel panelHK;
    private Button checkBoxHK;
    protected TabPage tabPage1;
    private Label label4;
    private Label label3;
    private Label label2;
    private Label label1;

    public MainForm()
    {
      this.InitializeComponent();
      this.mouseHook.MouseButtonDown += new MouseHook.MouseHookCallback(this.RecordMouseClick);
      Imports.RegisterHotKey(this.Handle, 1, 0, 112);
      Imports.RegisterHotKey(this.Handle, 2, 0, 113);
      this.miniControl.Owner = (Form) this;
      this.miniControl.Show();
      this.miniControl.Hide();
      this.miniControl.RecordEvent += (EventHandler) ((s, ee) => this.buttonRecord.PerformClick());
      this.miniControl.PlayEvent += (EventHandler) ((s, ee) => this.buttonPlay.PerformClick());
    }

    protected override void WndProc(ref Message m)
    {
      base.WndProc(ref m);
      if (m.Msg != 786 || this.tabControl1.SelectedIndex != 1 || (this.message.Visible || !this.Hotkeys))
        return;
      if (m.WParam.ToInt32() == 1)
      {
        this.buttonRecord.PerformClick();
      }
      else
      {
        if (m.WParam.ToInt32() != 2)
          return;
        this.buttonPlay.PerformClick();
      }
    }

    private void Form1_Load(object sender, EventArgs e)
    {
      foreach (System.Drawing.Color color in Enum.GetValues(typeof (KnownColor)).Cast<KnownColor>().Where<KnownColor>((Func<KnownColor, bool>) (kc => kc >= KnownColor.Transparent && kc < KnownColor.ButtonFace)).Select<KnownColor, System.Drawing.Color>((Func<KnownColor, System.Drawing.Color>) (kc => System.Drawing.Color.FromKnownColor(kc))))
      {
        if (!color.Name.Contains("Transparent") && !color.Name.Contains("White"))
          this.comboBoxColor.Items.Add((object) color.Name);
      }
      Thread.Sleep(100);
      this.loadSettings();
    }

    private void Form1_FormClosing(object sender, FormClosingEventArgs e)
    {
      this.mouseHook.MouseButtonDown -= new MouseHook.MouseHookCallback(this.RecordMouseClick);
      this.mouseHook.Uninstall();
      Imports.UnregisterHotKey(this.Handle, 1);
      Imports.UnregisterHotKey(this.Handle, 2);
      this.saveSettings();
      Thread.Sleep(100);
      if (this.mutex != null)
      {
        this.mutex.Close();
        this.mutex.Dispose();
      }
      this.miniControl.Dispose();
      this.message.Dispose();
      this.about.Dispose();
      this.windowList.Clear();
      this.windowList = (List<ListViewItem>) null;
      this.clickList.Clear();
      this.clickList = (List<ListViewItem>) null;
      Thread.Sleep(100);
      foreach (Process process in Process.GetProcessesByName("Growtopia"))
        process.Kill();
    }

    private void ButtonMinimize_Click(object sender, EventArgs e) => this.WindowState = FormWindowState.Minimized;

    private void ButtonClose_Click(object sender, EventArgs e) => this.Close();

    private void ShowMessage(string text)
    {
      if (this.TopMost)
        this.message.TopMost = true;
      else
        this.message.TopMost = false;
      this.message.content.Text = text;
      this.message.Owner = (Form) this;
      int num = (int) this.message.ShowDialog((IWin32Window) this.Owner);
    }

    private void ShowAbout()
    {
      if (this.TopMost)
        this.about.TopMost = true;
      else
        this.about.TopMost = false;
      this.about.Owner = (Form) this;
      int num = (int) this.about.ShowDialog((IWin32Window) this.Owner);
    }

    private void FrenzyMode_Tick(object sender, EventArgs e)
    {
      this.ChangeColor(ExtraColor.frenzyMode[ExtraColor.current++].Name);
      ExtraColor.current %= ExtraColor.frenzyMode.Count;
    }

    private void ChangeColor(string color)
    {
      System.Drawing.Color color1 = System.Drawing.Color.FromName(color);
      this.BackColor = color1;
      this.buttonMinimize.ForeColor = color1;
      this.buttonClose.ForeColor = color1;
      this.labelLogo.ForeColor = color1;
      this.buttonTab1.ForeColor = color1;
      this.buttonTab2.ForeColor = color1;
      this.buttonTab3.ForeColor = color1;
      this.panelTabSelectorActive.BackColor = color1;
      this.buttonLG.BackColor = color1;
      this.panelWL.BackColor = color1;
      this.labelWL.ForeColor = color1;
      this.listView1.ForeColor = color1;
      if (this.buttonRecord.BackColor != System.Drawing.Color.White)
        this.buttonRecord.BackColor = color1;
      if (this.buttonPlay.BackColor != System.Drawing.Color.White)
        this.buttonPlay.BackColor = color1;
      this.panelML.BackColor = color1;
      this.labelMLX.ForeColor = color1;
      this.labelMLY.ForeColor = color1;
      this.listView2.ForeColor = color1;
      this.labelCI.ForeColor = color1;
      this.TrackBarSlider.BackColor = color1;
      this.labelFC.ForeColor = color1;
      this.comboBoxColor.ForeColor = color1;
      this.labelSMC.ForeColor = color1;
      this.labelTM.ForeColor = color1;
      this.labelHK.ForeColor = color1;
      this.buttonAbout.BackColor = color1;
      if (this.ShowMini)
        this.checkBoxSMC.BackColor = color1;
      if (this.TopMost)
        this.checkBoxTM.BackColor = color1;
      if (this.Hotkeys)
        this.checkBoxHK.BackColor = color1;
      this.setAsPrimaryToolStripMenuItem.ForeColor = color1;
      this.closeToolStripMenuItem.ForeColor = color1;
      this.closeAllToolStripMenuItem.ForeColor = color1;
      this.removeToolStripMenuItem.ForeColor = color1;
      this.clearListToolStripMenuItem.ForeColor = color1;
      this.miniControl.updateStyle();
    }

    private void PanelForm_MouseDown(object sender, MouseEventArgs e)
    {
      this.formDrag = true;
      this.formX = Cursor.Position.X - this.Left;
      this.formY = Cursor.Position.Y - this.Top;
    }

    private void PanelForm_MouseMove(object sender, MouseEventArgs e)
    {
      if (!this.formDrag)
        return;
      Point position = Cursor.Position;
      this.Left = position.X - this.formX;
      position = Cursor.Position;
      this.Top = position.Y - this.formY;
    }

    private void PanelForm_MouseUp(object sender, MouseEventArgs e) => this.formDrag = false;

    private void Label1_MouseDown(object sender, MouseEventArgs e)
    {
      this.formDrag = true;
      this.formX = Cursor.Position.X - this.Left;
      this.formY = Cursor.Position.Y - this.Top;
    }

    private void Label1_MouseMove(object sender, MouseEventArgs e)
    {
      if (!this.formDrag)
        return;
      Point position = Cursor.Position;
      this.Left = position.X - this.formX;
      position = Cursor.Position;
      this.Top = position.Y - this.formY;
    }

    private void Label1_MouseUp(object sender, MouseEventArgs e) => this.formDrag = false;

    private void lockTabs()
    {
      if (this.buttonRecord.Text == "Stop" || this.buttonPlay.Text == "Stop")
      {
        this.buttonTab1.ForeColor = System.Drawing.Color.FromArgb(50, 50, 50);
        this.buttonTab3.ForeColor = System.Drawing.Color.FromArgb(50, 50, 50);
        this.buttonTab1.Enabled = false;
        this.buttonTab3.Enabled = false;
      }
      else
      {
        this.buttonTab1.ForeColor = this.BackColor;
        this.buttonTab3.ForeColor = this.BackColor;
        this.buttonTab1.Enabled = true;
        this.buttonTab3.Enabled = true;
      }
    }

    private void ButtonTab1_Click(object sender, EventArgs e)
    {
      Panel tabSelectorActive = this.panelTabSelectorActive;
      Point location = this.buttonTab1.Location;
      int x = location.X;
      location = this.panelTabSelectorActive.Location;
      int y = location.Y;
      Point point = new Point(x, y);
      tabSelectorActive.Location = point;
      this.tabControl1.SelectedIndex = 0;
      if (!this.ShowMini || !this.miniControl.Visible)
        return;
      this.miniControl.Hide();
    }

    private void ButtonTab2_Click(object sender, EventArgs e)
    {
      Panel tabSelectorActive = this.panelTabSelectorActive;
      Point location = this.buttonTab2.Location;
      int x = location.X;
      location = this.panelTabSelectorActive.Location;
      int y = location.Y;
      Point point = new Point(x, y);
      tabSelectorActive.Location = point;
      this.tabControl1.SelectedIndex = 1;
      if (this.ShowMini && !this.miniControl.Visible)
        this.miniControl.Show();
      if (this.miniControl.DesktopLocation.X == 0 && this.miniControl.DesktopLocation.Y == 0)
        return;
      this.miniControl.SetDesktopLocation(0, 0);
    }

    private void ButtonTab3_Click(object sender, EventArgs e)
    {
      if (!(this.buttonRecord.Text != "Stop") || !(this.buttonPlay.Text != "Stop"))
        return;
      Panel tabSelectorActive = this.panelTabSelectorActive;
      Point location = this.buttonTab3.Location;
      int x = location.X;
      location = this.panelTabSelectorActive.Location;
      int y = location.Y;
      Point point = new Point(x, y);
      tabSelectorActive.Location = point;
      this.tabControl1.SelectedIndex = 2;
      if (!this.ShowMini || !this.miniControl.Visible)
        return;
      this.miniControl.Hide();
    }

    private void TrackBarSlider_MouseDown(object sender, MouseEventArgs e)
    {
      this.sliderDrag = true;
      this.sliderX = Cursor.Position.X - this.TrackBarSlider.Left;
    }

    private void TrackBarSlider_MouseMove(object sender, MouseEventArgs e)
    {
      if (!this.sliderDrag)
        return;
      this.TrackBarSlider.Left = Cursor.Position.X - this.sliderX;
      Point location;
      if (this.TrackBarSlider.Location.X < 0)
      {
        while (true)
        {
          location = this.TrackBarSlider.Location;
          if (location.X < 0)
            this.TrackBarSlider.Location = new Point(0, 0);
          else
            break;
        }
      }
      else
      {
        location = this.TrackBarSlider.Location;
        if (location.X > 150)
        {
          while (true)
          {
            location = this.TrackBarSlider.Location;
            if (location.X > 150)
              this.TrackBarSlider.Location = new Point(150, 0);
            else
              break;
          }
        }
      }
      location = this.TrackBarSlider.Location;
      if (location.X < 25)
      {
        this.labelCI.Text = "Click Interval : " + 200.ToString();
      }
      else
      {
        location = this.TrackBarSlider.Location;
        if (location.X >= 25)
        {
          location = this.TrackBarSlider.Location;
          if (location.X < 50)
          {
            this.labelCI.Text = "Click Interval : " + 250.ToString();
            return;
          }
        }
        location = this.TrackBarSlider.Location;
        if (location.X >= 50)
        {
          location = this.TrackBarSlider.Location;
          if (location.X < 75)
          {
            this.labelCI.Text = "Click Interval : " + 300.ToString();
            return;
          }
        }
        location = this.TrackBarSlider.Location;
        if (location.X >= 75)
        {
          location = this.TrackBarSlider.Location;
          if (location.X < 100)
          {
            this.labelCI.Text = "Click Interval : " + 350.ToString();
            return;
          }
        }
        location = this.TrackBarSlider.Location;
        if (location.X >= 100)
        {
          location = this.TrackBarSlider.Location;
          if (location.X < 125)
          {
            this.labelCI.Text = "Click Interval : " + 400.ToString();
            return;
          }
        }
        location = this.TrackBarSlider.Location;
        if (location.X >= 125)
        {
          location = this.TrackBarSlider.Location;
          if (location.X < 150)
          {
            this.labelCI.Text = "Click Interval : " + 450.ToString();
            return;
          }
        }
        location = this.TrackBarSlider.Location;
        if (location.X < 150)
          return;
        location = this.TrackBarSlider.Location;
        if (location.X >= 160)
          return;
        this.labelCI.Text = "Click Interval : " + 500.ToString();
      }
    }

    private void TrackBarSlider_MouseUp(object sender, MouseEventArgs e)
    {
      this.sliderDrag = false;
      if (this.TrackBarSlider.Location.X < 25)
      {
        this.ClickInterval = 200;
        this.TrackBarSlider.Location = new Point(0, 0);
      }
      else if (this.TrackBarSlider.Location.X >= 25 && this.TrackBarSlider.Location.X < 50)
      {
        this.ClickInterval = 250;
        this.TrackBarSlider.Location = new Point(25, 0);
      }
      else if (this.TrackBarSlider.Location.X >= 50 && this.TrackBarSlider.Location.X < 75)
      {
        this.ClickInterval = 300;
        this.TrackBarSlider.Location = new Point(50, 0);
      }
      else if (this.TrackBarSlider.Location.X >= 75 && this.TrackBarSlider.Location.X < 100)
      {
        this.ClickInterval = 350;
        this.TrackBarSlider.Location = new Point(75, 0);
      }
      else if (this.TrackBarSlider.Location.X >= 100 && this.TrackBarSlider.Location.X < 125)
      {
        this.ClickInterval = 400;
        this.TrackBarSlider.Location = new Point(100, 0);
      }
      else if (this.TrackBarSlider.Location.X >= 125 && this.TrackBarSlider.Location.X < 150)
      {
        this.ClickInterval = 450;
        this.TrackBarSlider.Location = new Point(125, 0);
      }
      else
      {
        if (this.TrackBarSlider.Location.X < 150 || this.TrackBarSlider.Location.X >= 160)
          return;
        this.ClickInterval = 500;
        this.TrackBarSlider.Location = new Point(150, 0);
      }
    }

    private void loadSettings()
    {
      if (File.Exists("GTBitSettings.ini"))
      {
        IniFile iniFile = new IniFile("GTBitSettings.ini");
        this.ClickInterval = int.Parse(iniFile.Read("ClickInterval"));
        this.labelCI.Text = "Click Interval : " + this.ClickInterval.ToString();
        this.TrackBarSlider.Location = new Point(int.Parse(iniFile.Read("TrackBarSlider")), this.TrackBarSlider.Location.Y);
        string str = iniFile.Read("FormColor");
        if (str == "FrenzyMode 1x")
        {
          this.FrenzyMode.Interval = 100;
          if (!this.FrenzyMode.Enabled)
            this.FrenzyMode.Start();
          this.comboBoxColor.SelectedIndex = this.comboBoxColor.FindString("FrenzyMode 1x");
        }
        else if (str == "FrenzyMode 2x")
        {
          this.FrenzyMode.Interval = 50;
          if (!this.FrenzyMode.Enabled)
            this.FrenzyMode.Start();
          this.comboBoxColor.SelectedIndex = this.comboBoxColor.FindString("FrenzyMode 2x");
        }
        else if (str == "FrenzyMode 3x")
        {
          this.FrenzyMode.Interval = 25;
          if (!this.FrenzyMode.Enabled)
            this.FrenzyMode.Start();
          this.comboBoxColor.SelectedIndex = this.comboBoxColor.FindString("FrenzyMode 3x");
        }
        else if (str == "FrenzyMode 4x")
        {
          this.FrenzyMode.Interval = 5;
          if (!this.FrenzyMode.Enabled)
            this.FrenzyMode.Start();
          this.comboBoxColor.SelectedIndex = this.comboBoxColor.FindString("FrenzyMode 4x");
        }
        else
        {
          if (this.FrenzyMode.Enabled)
            this.FrenzyMode.Stop();
          this.ChangeColor(str);
          this.comboBoxColor.SelectedIndex = this.comboBoxColor.FindString(str);
        }
        this.ShowMini = iniFile.Read("ShowMini") == "true";
        if (iniFile.Read("TopMost") == "true")
          this.TopMost = true;
        else
          this.TopMost = false;
        if (iniFile.Read("Hotkeys") == "true")
          this.Hotkeys = true;
        else
          this.Hotkeys = false;
      }
      else
      {
        this.ClickInterval = 200;
        this.ShowMini = false;
        this.TopMost = false;
        this.FrenzyMode.Interval = 100;
        if (!this.FrenzyMode.Enabled)
          this.FrenzyMode.Start();
        this.comboBoxColor.SelectedIndex = this.comboBoxColor.FindString("FrenzyMode 1x");
      }
    }

    private void saveSettings()
    {
      IniFile iniFile = new IniFile("GTBitSettings.ini");
      iniFile.Write("ClickInterval", this.ClickInterval.ToString());
      iniFile.Write("TrackBarSlider", this.TrackBarSlider.Location.X.ToString());
      if (this.comboBoxColor.GetItemText(this.comboBoxColor.SelectedItem).Contains("FrenzyMode"))
        iniFile.Write("FormColor", this.comboBoxColor.GetItemText(this.comboBoxColor.SelectedItem));
      else
        iniFile.Write("FormColor", this.BackColor.Name);
      if (this.ShowMini)
        iniFile.Write("ShowMini", "true");
      else
        iniFile.Write("ShowMini", "false");
      if (this.TopMost)
        iniFile.Write("TopMost", "true");
      else
        iniFile.Write("TopMost", "false");
      if (this.Hotkeys)
        iniFile.Write("Hotkeys", "true");
      else
        iniFile.Write("Hotkeys", "false");
    }

    private void ButtonLaunchGrowtopia_Click(object sender, EventArgs e)
    {
      if (this.buttonLG.Enabled)
      {
        this.buttonLG.Text = "Wait...";
        this.buttonLG.Enabled = false;
        this.LaunchGrowtopia();
        this.buttonLG.Enabled = true;
        this.buttonLG.Text = "Launch Growtopia";
      }
      else
        this.ShowMessage("Please wait!");
    }

    private void LaunchGrowtopia()
    {
      RegistryKey registryKey = Registry.CurrentUser.OpenSubKey("SOFTWARE\\Growtopia");
      string str = (string) registryKey.GetValue("path", (object) "null") + "\\Growtopia.exe";
      registryKey.Dispose();
      if (File.Exists(str))
      {
        foreach (Process process in Process.GetProcessesByName("Growtopia"))
          Imports.SuspendProcess(process.Id);
        Thread.Sleep(100);
        if (this.mutex != null)
          this.mutex.Close();
        Process proc = Process.Start(str);
        proc.WaitForInputIdle();
        proc.WaitForInputIdle();
        proc.WaitForInputIdle();
        Thread.Sleep(100);
        this.mutex = new Mutex(true, "Growtopia");
        Thread.Sleep(100);
        foreach (HandleInfo enumProcessHandle in Handles.EnumProcessHandles(proc.Id))
        {
          if (enumProcessHandle.Type == "Mutant" && enumProcessHandle.Name.EndsWith("Growtopia"))
            Handles.CloseHandleEx(proc.Id, enumProcessHandle.Handle);
        }
        Thread.Sleep(100);
        foreach (Process process in Process.GetProcessesByName("Growtopia"))
          Imports.ResumeProcess(process.Id);
        Imports.SetWindowText(proc.MainWindowHandle, "Growtopia " + this.GetWindowNumber());
        this.listView1.Items.Add(proc.MainWindowTitle).Checked = true;
        this.SortList();
        proc.EnableRaisingEvents = true;
        proc.Exited += (EventHandler) ((ss, ee) => this.Process_Exited(ss, ee, proc));
      }
      else
        this.ShowMessage("Unable to locate Growtopia,\nPlease re-install.");
    }

        private void Process_Exited(object sender, EventArgs e, Process proc)
        {
            this.Invoke((MethodInvoker)delegate
            {
                foreach (ListViewItem item in listView1.Items)
                {
                    if (item.Text == proc.MainWindowTitle)
                    {
                        if (primaryWindow != null)
                        {
                            if (proc.MainWindowTitle == primaryWindow.MainWindowTitle)
                            {
                                toNull();
                            }
                        }
                        item.Remove();
                    }
                }
            });
        }

        private void toNull() => this.primaryWindow = (Process) null;

    private string GetWindowNumber()
    {
      string str1 = "";
      string str2 = "";
      foreach (Process process in Process.GetProcessesByName("Growtopia"))
        str1 += process.MainWindowTitle;
      for (int index = 1; index < 999; ++index)
        str2 = str2 + "[" + index.ToString() + "]-";
      string str3 = str2.Remove(str2.Length - 1);
      string str4 = str3;
      char[] chArray = new char[1]{ '-' };
      foreach (string str5 in str4.Split(chArray))
      {
        if (!str1.Contains(str5))
          return str5;
      }
      return str3;
    }

    private void SortList()
    {
      this.listView1.ListViewItemSorter = (IComparer) new ListViewSorter();
      this.listView1.Sorting = SortOrder.Descending;
      this.listView1.Sort();
    }

    private void Menu1_Opening(object sender, CancelEventArgs e)
    {
      if (this.listView1.SelectedItems.Count > 0)
      {
        if (this.primaryWindow != null && this.primaryWindow.MainWindowTitle == this.listView1.SelectedItems[0].Text)
          this.setAsPrimaryToolStripMenuItem.Enabled = false;
        else
          this.setAsPrimaryToolStripMenuItem.Enabled = true;
        this.closeToolStripMenuItem.Enabled = true;
      }
      else
      {
        this.setAsPrimaryToolStripMenuItem.Enabled = false;
        this.closeToolStripMenuItem.Enabled = false;
      }
      if (this.listView1.Items.Count < 1)
        this.closeAllToolStripMenuItem.Enabled = false;
      else
        this.closeAllToolStripMenuItem.Enabled = true;
    }

    private void setAsPrimaryToolStripMenuItem_Click(object sender, EventArgs e)
    {
      foreach (Process process in Process.GetProcessesByName("Growtopia"))
      {
        if (process.MainWindowTitle == this.listView1.SelectedItems[0].Text)
          this.primaryWindow = process;
      }
    }

    private void CloseToolStripMenuItem_Click(object sender, EventArgs e)
    {
      foreach (Process process in Process.GetProcessesByName("Growtopia"))
      {
        if (process.MainWindowTitle == this.listView1.SelectedItems[0].Text)
          process.Kill();
      }
    }

    private void CloseAllToolStripMenuItem_Click(object sender, EventArgs e)
    {
      foreach (Process process in Process.GetProcessesByName("Growtopia"))
        process.Kill();
    }

    private void ButtonRecord_Click(object sender, EventArgs e)
    {
      if (this.primaryWindow != null)
      {
        if (this.listView1.Items.Count > 0)
        {
          if (this.buttonPlay.Text != "Stop")
          {
            if (this.buttonRecord.Text == "Record")
            {
              this.buttonRecord.Text = "Stop";
              this.buttonRecord.BackColor = System.Drawing.Color.White;
              this.miniControl.updateButtons();
              this.lockTabs();
              this.mouseHook.Install();
              Imports.SetForegroundWindow(this.primaryWindow.MainWindowHandle);
            }
            else
            {
              this.mouseHook.Uninstall();
              this.buttonRecord.Text = "Record";
              this.buttonRecord.BackColor = this.BackColor;
              this.miniControl.updateButtons();
              this.lockTabs();
            }
          }
          else
            this.ShowMessage("You should stop Play mode first.");
        }
        else
          this.ShowMessage("Growtopia window list is empty.");
      }
      else
        this.ShowMessage("Primary window is not set.");
    }

    private void RecordMouseClick(MouseHook.MSLLHOOKSTRUCT button)
    {
      if (this.primaryWindow != null)
      {
        Imports.RECT lpRect1;
        Imports.GetWindowRect(this.primaryWindow.MainWindowHandle, out lpRect1);
        Imports.RECT lpRect2;
        Imports.GetClientRect(this.primaryWindow.MainWindowHandle, out lpRect2);
        Point lpPoint1 = new Point(lpRect2.Left, lpRect2.Top);
        Imports.ClientToScreen(this.primaryWindow.MainWindowHandle, out lpPoint1);
        Point lpPoint2 = new Point(lpRect2.Right, lpRect2.Bottom);
        Imports.ClientToScreen(this.primaryWindow.MainWindowHandle, out lpPoint2);
        int num1 = lpPoint1.Y - lpRect1.Top;
        int num2 = lpRect1.Bottom - lpPoint2.Y;
        int num3 = lpPoint1.X - lpRect1.Left;
        int num4 = lpRect1.Right - lpPoint2.X;
        int num5 = lpRect1.Right - lpRect1.Left - num3 - num4;
        int num6 = lpRect1.Bottom - lpRect1.Top - num1 - num2;
        Point position = Cursor.Position;
        int num7 = position.X - lpRect1.Left - num3;
        position = Cursor.Position;
        int num8 = position.Y - lpRect1.Top - num1;
        if (!(Imports.GetForegroundWindow() == this.primaryWindow.MainWindowHandle) || num7 < 0 || (num8 < 0 || num7 > num5) || num8 > num6)
          return;
        this.listView2.Items.Add(new ListViewItem(new string[2]
        {
          num7.ToString(),
          num8.ToString()
        }));
      }
      else
      {
        this.mouseHook.Uninstall();
        this.buttonRecord.Text = "Record";
        this.buttonRecord.BackColor = this.BackColor;
        this.miniControl.updateButtons();
        this.lockTabs();
        this.ShowMessage("It seems the primary window has\nexited.");
      }
    }

    private void ButtonPlay_Click(object sender, EventArgs e)
    {
      if (this.listView1.Items.Count > 0)
      {
        if (this.listView2.Items.Count > 0)
        {
          if (this.buttonRecord.Text != "Stop")
          {
            if (!Workflow.Active)
            {
              this.buttonPlay.Text = "Stop";
              this.buttonPlay.BackColor = System.Drawing.Color.White;
              this.miniControl.updateButtons();
              this.lockTabs();
              lock (this.windowList)
              {
                this.windowList.Clear();
                this.windowList = this.GetListViewItems(this.listView1).Cast<ListViewItem>().Select<ListViewItem, ListViewItem>((Func<ListViewItem, ListViewItem>) (item => item)).ToList<ListViewItem>();
              }
              lock (this.clickList)
              {
                this.clickList.Clear();
                this.clickList = this.GetListViewItems(this.listView2).Cast<ListViewItem>().Select<ListViewItem, ListViewItem>((Func<ListViewItem, ListViewItem>) (item => item)).ToList<ListViewItem>();
              }
              Thread thread = new Thread((ThreadStart) (() =>
              {
                Workflow.Active = true;
                if (Workflow.PerformClicks(this.windowList, this.clickList, this.ClickInterval) == 1)
                  this.Invoke((Delegate) (() => this.ShowMessage("The Growtopia window list has\nbeen modified or one of the\nGrowtopia windows has\nbeen closed.")));
                Workflow.Active = false;
                this.Invoke((Delegate) (() =>
                {
                  this.buttonPlay.Text = "Play";
                  this.buttonPlay.BackColor = this.BackColor;
                  this.miniControl.updateButtons();
                  this.lockTabs();
                }));
              }));
              thread.SetApartmentState(ApartmentState.STA);
              thread.Start();
            }
            else
              Workflow.Active = false;
          }
          else
            this.ShowMessage("You should stop Record mode first.");
        }
        else
          this.ShowMessage("Clicks list is empty.");
      }
      else
        this.ShowMessage("Growtopia window list is empty.");
    }

    private ListView.ListViewItemCollection GetListViewItems(ListView listview)
    {
      ListView.ListViewItemCollection viewItemCollection = new ListView.ListViewItemCollection(new ListView());
      if (!listview.InvokeRequired)
      {
        foreach (ListViewItem listViewItem in listview.Items)
          viewItemCollection.Add((ListViewItem) listViewItem.Clone());
        return viewItemCollection;
      }
      return (ListView.ListViewItemCollection) this.Invoke((Delegate) new MainForm.GetItems(this.GetListViewItems), (object) listview);
    }

    private void RemoveToolStripMenuItem_Click(object sender, EventArgs e) => this.listView2.Items.Remove(this.listView2.SelectedItems[0]);

    private void ClearListToolStripMenuItem_Click(object sender, EventArgs e)
    {
      foreach (ListViewItem listViewItem in this.listView2.Items)
        this.listView2.Items.Remove(listViewItem);
    }

    private void Menu2_Opening(object sender, CancelEventArgs e)
    {
      if (this.buttonPlay.Text == "Stop")
      {
        this.removeToolStripMenuItem.Enabled = false;
        this.clearListToolStripMenuItem.Enabled = false;
      }
      else
      {
        if (this.listView2.SelectedItems.Count == 0)
          this.removeToolStripMenuItem.Enabled = false;
        else
          this.removeToolStripMenuItem.Enabled = true;
        if (this.listView2.Items.Count < 1)
          this.clearListToolStripMenuItem.Enabled = false;
        else
          this.clearListToolStripMenuItem.Enabled = true;
      }
    }

    private void ComboBox1_SelectedIndexChanged(object sender, EventArgs e)
    {
      if (this.comboBoxColor.GetItemText(this.comboBoxColor.SelectedItem) == "FrenzyMode 1x")
      {
        this.FrenzyMode.Interval = 100;
        if (this.FrenzyMode.Enabled)
          return;
        this.FrenzyMode.Start();
      }
      else if (this.comboBoxColor.GetItemText(this.comboBoxColor.SelectedItem) == "FrenzyMode 2x")
      {
        this.FrenzyMode.Interval = 50;
        if (this.FrenzyMode.Enabled)
          return;
        this.FrenzyMode.Start();
      }
      else if (this.comboBoxColor.GetItemText(this.comboBoxColor.SelectedItem) == "FrenzyMode 3x")
      {
        this.FrenzyMode.Interval = 25;
        if (this.FrenzyMode.Enabled)
          return;
        this.FrenzyMode.Start();
      }
      else if (this.comboBoxColor.GetItemText(this.comboBoxColor.SelectedItem) == "FrenzyMode 4x")
      {
        this.FrenzyMode.Interval = 5;
        if (this.FrenzyMode.Enabled)
          return;
        this.FrenzyMode.Start();
      }
      else
      {
        if (this.FrenzyMode.Enabled)
          this.FrenzyMode.Stop();
        this.ChangeColor(this.comboBoxColor.SelectedItem.ToString());
      }
    }

    private void CheckBoxSMC_Click(object sender, EventArgs e)
    {
      if (!this.ShowMini)
      {
        this.ShowMini = true;
        this.checkBoxSMC.BackColor = this.BackColor;
      }
      else
      {
        this.ShowMini = false;
        this.checkBoxSMC.BackColor = System.Drawing.Color.FromArgb(50, 50, 50);
      }
    }

    private void CheckBoxTM_Click(object sender, EventArgs e)
    {
      if (!this.TopMost)
      {
        this.TopMost = true;
        this.checkBoxTM.BackColor = this.BackColor;
      }
      else
      {
        this.TopMost = false;
        this.checkBoxTM.BackColor = System.Drawing.Color.FromArgb(50, 50, 50);
      }
    }

    private void checkBoxHK_Click(object sender, EventArgs e)
    {
      if (!this.Hotkeys)
      {
        this.Hotkeys = true;
        this.checkBoxHK.BackColor = this.BackColor;
      }
      else
      {
        this.Hotkeys = false;
        this.checkBoxHK.BackColor = System.Drawing.Color.FromArgb(50, 50, 50);
      }
    }

    private void panelForm_Paint(object sender, PaintEventArgs e)
    {
    }

    private void ButtonAbout_Click(object sender, EventArgs e) => this.ShowAbout();

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.components = (IContainer) new Container();
      ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof (MainForm));
      this.panelForm = new Panel();
      this.buttonMinimize = new Button();
      this.buttonClose = new Button();
      this.TabSelector = new Panel();
      this.buttonTab1 = new Button();
      this.buttonTab3 = new Button();
      this.buttonTab2 = new Button();
      this.panelTabSelectorActive = new Panel();
      this.panelTabControl = new Panel();
      this.tabControl1 = new TabControl();
      this.tabPage1 = new TabPage();
      this.panelWL = new Panel();
      this.panelWLH = new Panel();
      this.labelWL = new Label();
      this.listView1 = new ListView();
      this.columnHeader1 = new ColumnHeader();
      this.Menu1 = new ContextMenuStrip(this.components);
      this.setAsPrimaryToolStripMenuItem = new ToolStripMenuItem();
      this.closeToolStripMenuItem = new ToolStripMenuItem();
      this.closeAllToolStripMenuItem = new ToolStripMenuItem();
      this.buttonLG = new Button();
      this.tabPage2 = new TabPage();
      this.panelML = new Panel();
      this.panelMLH = new Panel();
      this.labelMLY = new Label();
      this.labelMLX = new Label();
      this.listView2 = new ListView();
      this.columnHeader2 = new ColumnHeader();
      this.columnHeader3 = new ColumnHeader();
      this.Menu2 = new ContextMenuStrip(this.components);
      this.removeToolStripMenuItem = new ToolStripMenuItem();
      this.clearListToolStripMenuItem = new ToolStripMenuItem();
      this.buttonPlay = new Button();
      this.buttonRecord = new Button();
      this.tabPage3 = new TabPage();
      this.labelHK = new Label();
      this.panelHK = new Panel();
      this.checkBoxHK = new Button();
      this.labelTM = new Label();
      this.panelTM = new Panel();
      this.checkBoxTM = new Button();
      this.labelSMC = new Label();
      this.panelSMC = new Panel();
      this.checkBoxSMC = new Button();
      this.panelTrackBar = new Panel();
      this.TrackBarSlider = new Button();
      this.panelTrackBar2 = new Panel();
      this.comboBoxColor = new ComboBox();
      this.labelFC = new Label();
      this.labelCI = new Label();
      this.buttonAbout = new Button();
      this.labelLogo = new Label();
      this.FrenzyMode = new System.Windows.Forms.Timer(this.components);
      this.label1 = new Label();
      this.label2 = new Label();
      this.label3 = new Label();
      this.label4 = new Label();
      this.panelForm.SuspendLayout();
      this.TabSelector.SuspendLayout();
      this.panelTabControl.SuspendLayout();
      this.tabControl1.SuspendLayout();
      this.tabPage1.SuspendLayout();
      this.panelWL.SuspendLayout();
      this.panelWLH.SuspendLayout();
      this.Menu1.SuspendLayout();
      this.tabPage2.SuspendLayout();
      this.panelML.SuspendLayout();
      this.panelMLH.SuspendLayout();
      this.Menu2.SuspendLayout();
      this.tabPage3.SuspendLayout();
      this.panelHK.SuspendLayout();
      this.panelTM.SuspendLayout();
      this.panelSMC.SuspendLayout();
      this.panelTrackBar.SuspendLayout();
      this.SuspendLayout();
      this.panelForm.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
      this.panelForm.BackColor = System.Drawing.Color.FromArgb(10, 10, 10);
      this.panelForm.Controls.Add((Control) this.label4);
      this.panelForm.Controls.Add((Control) this.label3);
      this.panelForm.Controls.Add((Control) this.label2);
      this.panelForm.Controls.Add((Control) this.label1);
      this.panelForm.Controls.Add((Control) this.buttonMinimize);
      this.panelForm.Controls.Add((Control) this.buttonClose);
      this.panelForm.Controls.Add((Control) this.TabSelector);
      this.panelForm.Controls.Add((Control) this.panelTabControl);
      this.panelForm.Controls.Add((Control) this.labelLogo);
      this.panelForm.Location = new Point(0, 3);
      this.panelForm.Name = "panelForm";
      this.panelForm.Size = new Size(388, 506);
      this.panelForm.TabIndex = 2;
      this.panelForm.Paint += new PaintEventHandler(this.panelForm_Paint);
      this.panelForm.MouseDown += new MouseEventHandler(this.PanelForm_MouseDown);
      this.panelForm.MouseMove += new MouseEventHandler(this.PanelForm_MouseMove);
      this.panelForm.MouseUp += new MouseEventHandler(this.PanelForm_MouseUp);
      this.buttonMinimize.FlatAppearance.BorderSize = 0;
      this.buttonMinimize.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(35, 35, 35);
      this.buttonMinimize.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(35, 35, 35);
      this.buttonMinimize.FlatStyle = FlatStyle.Flat;
      this.buttonMinimize.Font = new Font("Caviar Dreams", 9.75f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.buttonMinimize.ForeColor = System.Drawing.Color.Lime;
      this.buttonMinimize.Location = new Point(332, 0);
      this.buttonMinimize.Name = "buttonMinimize";
      this.buttonMinimize.Size = new Size(20, 25);
      this.buttonMinimize.TabIndex = 0;
      this.buttonMinimize.TabStop = false;
      this.buttonMinimize.Text = "o";
      this.buttonMinimize.UseVisualStyleBackColor = true;
      this.buttonMinimize.Click += new EventHandler(this.ButtonMinimize_Click);
      this.buttonClose.FlatAppearance.BorderSize = 0;
      this.buttonClose.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(35, 35, 35);
      this.buttonClose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(35, 35, 35);
      this.buttonClose.FlatStyle = FlatStyle.Flat;
      this.buttonClose.Font = new Font("Caviar Dreams", 9.75f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.buttonClose.ForeColor = System.Drawing.Color.Lime;
      this.buttonClose.Location = new Point(358, 0);
      this.buttonClose.Name = "buttonClose";
      this.buttonClose.Size = new Size(20, 25);
      this.buttonClose.TabIndex = 0;
      this.buttonClose.TabStop = false;
      this.buttonClose.Text = "o";
      this.buttonClose.UseVisualStyleBackColor = true;
      this.buttonClose.Click += new EventHandler(this.ButtonClose_Click);
      this.TabSelector.BackColor = System.Drawing.Color.FromArgb(50, 50, 50);
      this.TabSelector.Controls.Add((Control) this.buttonTab1);
      this.TabSelector.Controls.Add((Control) this.buttonTab3);
      this.TabSelector.Controls.Add((Control) this.buttonTab2);
      this.TabSelector.Controls.Add((Control) this.panelTabSelectorActive);
      this.TabSelector.Font = new Font("Caviar Dreams", 9.75f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.TabSelector.Location = new Point(80, 72);
      this.TabSelector.Name = "TabSelector";
      this.TabSelector.Size = new Size(250, 43);
      this.TabSelector.TabIndex = 0;
      this.buttonTab1.BackColor = System.Drawing.Color.FromArgb(10, 10, 10);
      this.buttonTab1.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(10, 10, 10);
      this.buttonTab1.FlatAppearance.BorderSize = 0;
      this.buttonTab1.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(10, 10, 10);
      this.buttonTab1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(10, 10, 10);
      this.buttonTab1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(10, 10, 10);
      this.buttonTab1.FlatStyle = FlatStyle.Flat;
      this.buttonTab1.Font = new Font("Caviar Dreams", 9.75f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.buttonTab1.ForeColor = System.Drawing.Color.Lime;
      this.buttonTab1.Location = new Point(0, 0);
      this.buttonTab1.Name = "buttonTab1";
      this.buttonTab1.Size = new Size(70, 43);
      this.buttonTab1.TabIndex = 0;
      this.buttonTab1.TabStop = false;
      this.buttonTab1.Text = "Home";
      this.buttonTab1.TextAlign = ContentAlignment.MiddleLeft;
      this.buttonTab1.UseVisualStyleBackColor = false;
      this.buttonTab1.Click += new EventHandler(this.ButtonTab1_Click);
      this.buttonTab3.BackColor = System.Drawing.Color.FromArgb(10, 10, 10);
      this.buttonTab3.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(10, 10, 10);
      this.buttonTab3.FlatAppearance.BorderSize = 0;
      this.buttonTab3.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(10, 10, 10);
      this.buttonTab3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(10, 10, 10);
      this.buttonTab3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(10, 10, 10);
      this.buttonTab3.FlatStyle = FlatStyle.Flat;
      this.buttonTab3.Font = new Font("Caviar Dreams", 9.75f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.buttonTab3.ForeColor = System.Drawing.Color.Lime;
      this.buttonTab3.Location = new Point(140, -3);
      this.buttonTab3.Name = "buttonTab3";
      this.buttonTab3.Size = new Size(110, 46);
      this.buttonTab3.TabIndex = 0;
      this.buttonTab3.TabStop = false;
      this.buttonTab3.Text = "Settings";
      this.buttonTab3.TextAlign = ContentAlignment.MiddleLeft;
      this.buttonTab3.UseVisualStyleBackColor = false;
      this.buttonTab3.Click += new EventHandler(this.ButtonTab3_Click);
      this.buttonTab2.BackColor = System.Drawing.Color.FromArgb(10, 10, 10);
      this.buttonTab2.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(10, 10, 10);
      this.buttonTab2.FlatAppearance.BorderSize = 0;
      this.buttonTab2.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(10, 10, 10);
      this.buttonTab2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(10, 10, 10);
      this.buttonTab2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(10, 10, 10);
      this.buttonTab2.FlatStyle = FlatStyle.Flat;
      this.buttonTab2.Font = new Font("Caviar Dreams", 9.75f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.buttonTab2.ForeColor = System.Drawing.Color.Lime;
      this.buttonTab2.Location = new Point(70, 0);
      this.buttonTab2.Name = "buttonTab2";
      this.buttonTab2.Size = new Size(70, 43);
      this.buttonTab2.TabIndex = 0;
      this.buttonTab2.TabStop = false;
      this.buttonTab2.Text = "Macro";
      this.buttonTab2.TextAlign = ContentAlignment.MiddleLeft;
      this.buttonTab2.UseVisualStyleBackColor = false;
      this.buttonTab2.Click += new EventHandler(this.ButtonTab2_Click);
      this.panelTabSelectorActive.BackColor = System.Drawing.Color.Lime;
      this.panelTabSelectorActive.Location = new Point(0, 30);
      this.panelTabSelectorActive.Name = "panelTabSelectorActive";
      this.panelTabSelectorActive.Size = new Size(65, 4);
      this.panelTabSelectorActive.TabIndex = 0;
      this.panelTabControl.BackColor = System.Drawing.Color.FromArgb(10, 10, 10);
      this.panelTabControl.Controls.Add((Control) this.tabControl1);
      this.panelTabControl.Location = new Point(25, 121);
      this.panelTabControl.Name = "panelTabControl";
      this.panelTabControl.Size = new Size(220, 353);
      this.panelTabControl.TabIndex = 4;
      this.tabControl1.Controls.Add((Control) this.tabPage1);
      this.tabControl1.Controls.Add((Control) this.tabPage2);
      this.tabControl1.Controls.Add((Control) this.tabPage3);
      this.tabControl1.ItemSize = new Size(58, 0);
      this.tabControl1.Location = new Point(-4, -22);
      this.tabControl1.Name = "tabControl1";
      this.tabControl1.SelectedIndex = 0;
      this.tabControl1.Size = new Size(228, 379);
      this.tabControl1.TabIndex = 2;
      this.tabControl1.TabStop = false;
      this.tabPage1.AllowDrop = true;
      this.tabPage1.BackColor = System.Drawing.Color.FromArgb(10, 10, 10);
      this.tabPage1.BackgroundImageLayout = ImageLayout.Stretch;
      this.tabPage1.CausesValidation = false;
      this.tabPage1.Controls.Add((Control) this.panelWLH);
      this.tabPage1.Controls.Add((Control) this.panelWL);
      this.tabPage1.Controls.Add((Control) this.buttonLG);
      this.tabPage1.Font = new Font("Caviar Dreams", 9.75f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.tabPage1.Location = new Point(4, 22);
      this.tabPage1.Name = "tabPage1";
      this.tabPage1.RightToLeft = RightToLeft.Yes;
      this.tabPage1.Size = new Size(220, 353);
      this.tabPage1.TabIndex = 0;
      this.tabPage1.Text = "tabPage1";
      this.panelWL.BackColor = System.Drawing.Color.Lime;
      this.panelWL.Controls.Add((Control) this.listView1);
      this.panelWL.Font = new Font("Caviar Dreams", 9.75f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.panelWL.Location = new Point(10, 73);
      this.panelWL.Name = "panelWL";
      this.panelWL.Size = new Size(200, 270);
      this.panelWL.TabIndex = 1;
      this.panelWLH.BackColor = System.Drawing.Color.FromArgb(10, 10, 10);
      this.panelWLH.Controls.Add((Control) this.labelWL);
      this.panelWLH.Location = new Point(10, 73);
      this.panelWLH.Name = "panelWLH";
      this.panelWLH.Size = new Size(207, 35);
      this.panelWLH.TabIndex = 0;
      this.labelWL.AutoSize = true;
      this.labelWL.Font = new Font("Caviar Dreams", 9.75f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.labelWL.ForeColor = System.Drawing.Color.Lime;
      this.labelWL.Location = new Point(10, 10);
      this.labelWL.Name = "labelWL";
      this.labelWL.Size = new Size(79, 17);
      this.labelWL.TabIndex = 0;
      this.labelWL.Text = "Window List";
      this.listView1.BackColor = System.Drawing.Color.FromArgb(10, 10, 10);
      this.listView1.BorderStyle = BorderStyle.None;
      this.listView1.CheckBoxes = true;
      this.listView1.Columns.AddRange(new ColumnHeader[1]
      {
        this.columnHeader1
      });
      this.listView1.ContextMenuStrip = this.Menu1;
      this.listView1.Font = new Font("Caviar Dreams", 9.75f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.listView1.ForeColor = System.Drawing.Color.Lime;
      this.listView1.FullRowSelect = true;
      this.listView1.HeaderStyle = ColumnHeaderStyle.None;
      this.listView1.HideSelection = false;
      this.listView1.Location = new Point(0, 32);
      this.listView1.MultiSelect = false;
      this.listView1.Name = "listView1";
      this.listView1.Size = new Size(256, 238);
      this.listView1.TabIndex = 0;
      this.listView1.TabStop = false;
      this.listView1.UseCompatibleStateImageBehavior = false;
      this.listView1.View = View.Details;
      this.columnHeader1.Text = "Window Title";
      this.columnHeader1.Width = 170;
      this.Menu1.BackColor = System.Drawing.Color.FromArgb(10, 10, 10);
      this.Menu1.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.Menu1.ImageScalingSize = new Size(20, 20);
      this.Menu1.Items.AddRange(new ToolStripItem[3]
      {
        (ToolStripItem) this.setAsPrimaryToolStripMenuItem,
        (ToolStripItem) this.closeToolStripMenuItem,
        (ToolStripItem) this.closeAllToolStripMenuItem
      });
      this.Menu1.Name = "Menu1";
      this.Menu1.ShowImageMargin = false;
      this.Menu1.ShowItemToolTips = false;
      this.Menu1.Size = new Size(139, 70);
      this.Menu1.Opening += new CancelEventHandler(this.Menu1_Opening);
      this.setAsPrimaryToolStripMenuItem.ForeColor = System.Drawing.Color.Lime;
      this.setAsPrimaryToolStripMenuItem.Name = "setAsPrimaryToolStripMenuItem";
      this.setAsPrimaryToolStripMenuItem.Size = new Size(138, 22);
      this.setAsPrimaryToolStripMenuItem.Text = "Set as Primary";
      this.setAsPrimaryToolStripMenuItem.Click += new EventHandler(this.setAsPrimaryToolStripMenuItem_Click);
      this.closeToolStripMenuItem.ForeColor = System.Drawing.Color.Lime;
      this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
      this.closeToolStripMenuItem.Size = new Size(138, 22);
      this.closeToolStripMenuItem.Text = "Close";
      this.closeToolStripMenuItem.Click += new EventHandler(this.CloseToolStripMenuItem_Click);
      this.closeAllToolStripMenuItem.ForeColor = System.Drawing.Color.Lime;
      this.closeAllToolStripMenuItem.Name = "closeAllToolStripMenuItem";
      this.closeAllToolStripMenuItem.Size = new Size(138, 22);
      this.closeAllToolStripMenuItem.Text = "Close All";
      this.closeAllToolStripMenuItem.Click += new EventHandler(this.CloseAllToolStripMenuItem_Click);
      this.buttonLG.BackColor = System.Drawing.Color.Lime;
      this.buttonLG.FlatAppearance.BorderSize = 0;
      this.buttonLG.FlatStyle = FlatStyle.Flat;
      this.buttonLG.Font = new Font("Caviar Dreams", 9.75f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.buttonLG.ForeColor = System.Drawing.Color.Black;
      this.buttonLG.Location = new Point(10, 10);
      this.buttonLG.Name = "buttonLG";
      this.buttonLG.Size = new Size(200, 50);
      this.buttonLG.TabIndex = 0;
      this.buttonLG.TabStop = false;
      this.buttonLG.Text = "Launch Growtopia";
      this.buttonLG.TextAlign = ContentAlignment.BottomLeft;
      this.buttonLG.UseVisualStyleBackColor = false;
      this.buttonLG.Click += new EventHandler(this.ButtonLaunchGrowtopia_Click);
      this.tabPage2.BackColor = System.Drawing.Color.FromArgb(10, 10, 10);
      this.tabPage2.Controls.Add((Control) this.panelML);
      this.tabPage2.Controls.Add((Control) this.buttonPlay);
      this.tabPage2.Controls.Add((Control) this.buttonRecord);
      this.tabPage2.Font = new Font("Caviar Dreams", 9.75f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.tabPage2.Location = new Point(4, 22);
      this.tabPage2.Name = "tabPage2";
      this.tabPage2.Size = new Size(220, 353);
      this.tabPage2.TabIndex = 1;
      this.tabPage2.Text = "tabPage2";
      this.panelML.BackColor = System.Drawing.Color.Lime;
      this.panelML.Controls.Add((Control) this.panelMLH);
      this.panelML.Controls.Add((Control) this.listView2);
      this.panelML.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.panelML.Location = new Point(10, 73);
      this.panelML.Name = "panelML";
      this.panelML.Size = new Size(200, 270);
      this.panelML.TabIndex = 0;
      this.panelMLH.BackColor = System.Drawing.Color.FromArgb(10, 10, 10);
      this.panelMLH.Controls.Add((Control) this.labelMLY);
      this.panelMLH.Controls.Add((Control) this.labelMLX);
      this.panelMLH.Location = new Point(2, 2);
      this.panelMLH.Name = "panelMLH";
      this.panelMLH.Size = new Size(196, 35);
      this.panelMLH.TabIndex = 0;
      this.labelMLY.AutoSize = true;
      this.labelMLY.Font = new Font("Caviar Dreams", 9.75f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.labelMLY.ForeColor = System.Drawing.Color.Lime;
      this.labelMLY.Location = new Point(95, 10);
      this.labelMLY.Name = "labelMLY";
      this.labelMLY.Size = new Size(17, 17);
      this.labelMLY.TabIndex = 0;
      this.labelMLY.Text = "Y";
      this.labelMLX.AutoSize = true;
      this.labelMLX.Font = new Font("Caviar Dreams", 9.75f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.labelMLX.ForeColor = System.Drawing.Color.Lime;
      this.labelMLX.Location = new Point(10, 10);
      this.labelMLX.Name = "labelMLX";
      this.labelMLX.Size = new Size(17, 17);
      this.labelMLX.TabIndex = 0;
      this.labelMLX.Text = "X";
      this.listView2.BackColor = System.Drawing.Color.FromArgb(10, 10, 10);
      this.listView2.BorderStyle = BorderStyle.None;
      this.listView2.Columns.AddRange(new ColumnHeader[2]
      {
        this.columnHeader2,
        this.columnHeader3
      });
      this.listView2.ContextMenuStrip = this.Menu2;
      this.listView2.Font = new Font("Caviar Dreams", 9.75f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.listView2.ForeColor = System.Drawing.Color.Lime;
      this.listView2.FullRowSelect = true;
      this.listView2.HeaderStyle = ColumnHeaderStyle.None;
      this.listView2.HideSelection = false;
      this.listView2.Location = new Point(2, 41);
      this.listView2.Name = "listView2";
      this.listView2.Size = new Size(196, 227);
      this.listView2.TabIndex = 0;
      this.listView2.TabStop = false;
      this.listView2.UseCompatibleStateImageBehavior = false;
      this.listView2.View = View.Details;
      this.columnHeader2.Text = "Window Title";
      this.columnHeader2.Width = 85;
      this.columnHeader3.Width = 85;
      this.Menu2.BackColor = System.Drawing.Color.FromArgb(10, 10, 10);
      this.Menu2.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.Menu2.ImageScalingSize = new Size(20, 20);
      this.Menu2.Items.AddRange(new ToolStripItem[2]
      {
        (ToolStripItem) this.removeToolStripMenuItem,
        (ToolStripItem) this.clearListToolStripMenuItem
      });
      this.Menu2.Name = "Menu1";
      this.Menu2.ShowImageMargin = false;
      this.Menu2.ShowItemToolTips = false;
      this.Menu2.Size = new Size(107, 48);
      this.Menu2.Opening += new CancelEventHandler(this.Menu2_Opening);
      this.removeToolStripMenuItem.ForeColor = System.Drawing.Color.Lime;
      this.removeToolStripMenuItem.Name = "removeToolStripMenuItem";
      this.removeToolStripMenuItem.Size = new Size(106, 22);
      this.removeToolStripMenuItem.Text = "Remove";
      this.removeToolStripMenuItem.Click += new EventHandler(this.RemoveToolStripMenuItem_Click);
      this.clearListToolStripMenuItem.ForeColor = System.Drawing.Color.Lime;
      this.clearListToolStripMenuItem.Name = "clearListToolStripMenuItem";
      this.clearListToolStripMenuItem.Size = new Size(106, 22);
      this.clearListToolStripMenuItem.Text = "Clear List";
      this.clearListToolStripMenuItem.Click += new EventHandler(this.ClearListToolStripMenuItem_Click);
      this.buttonPlay.BackColor = System.Drawing.Color.Lime;
      this.buttonPlay.FlatAppearance.BorderSize = 0;
      this.buttonPlay.FlatStyle = FlatStyle.Flat;
      this.buttonPlay.Font = new Font("Caviar Dreams", 9.75f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.buttonPlay.ForeColor = System.Drawing.Color.Black;
      this.buttonPlay.Location = new Point(91, 10);
      this.buttonPlay.Name = "buttonPlay";
      this.buttonPlay.Size = new Size(119, 50);
      this.buttonPlay.TabIndex = 0;
      this.buttonPlay.TabStop = false;
      this.buttonPlay.Text = "Play";
      this.buttonPlay.TextAlign = ContentAlignment.BottomLeft;
      this.buttonPlay.UseVisualStyleBackColor = false;
      this.buttonPlay.Click += new EventHandler(this.ButtonPlay_Click);
      this.buttonRecord.BackColor = System.Drawing.Color.Lime;
      this.buttonRecord.FlatAppearance.BorderSize = 0;
      this.buttonRecord.FlatStyle = FlatStyle.Flat;
      this.buttonRecord.Font = new Font("Caviar Dreams", 9.75f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.buttonRecord.ForeColor = System.Drawing.Color.Black;
      this.buttonRecord.Location = new Point(10, 10);
      this.buttonRecord.Name = "buttonRecord";
      this.buttonRecord.Size = new Size(75, 50);
      this.buttonRecord.TabIndex = 0;
      this.buttonRecord.TabStop = false;
      this.buttonRecord.Text = "Record";
      this.buttonRecord.TextAlign = ContentAlignment.BottomLeft;
      this.buttonRecord.UseVisualStyleBackColor = false;
      this.buttonRecord.Click += new EventHandler(this.ButtonRecord_Click);
      this.tabPage3.BackColor = System.Drawing.Color.FromArgb(10, 10, 10);
      this.tabPage3.Controls.Add((Control) this.labelHK);
      this.tabPage3.Controls.Add((Control) this.panelHK);
      this.tabPage3.Controls.Add((Control) this.labelTM);
      this.tabPage3.Controls.Add((Control) this.panelTM);
      this.tabPage3.Controls.Add((Control) this.labelSMC);
      this.tabPage3.Controls.Add((Control) this.panelSMC);
      this.tabPage3.Controls.Add((Control) this.panelTrackBar);
      this.tabPage3.Controls.Add((Control) this.comboBoxColor);
      this.tabPage3.Controls.Add((Control) this.labelFC);
      this.tabPage3.Controls.Add((Control) this.labelCI);
      this.tabPage3.Controls.Add((Control) this.buttonAbout);
      this.tabPage3.Font = new Font("Caviar Dreams", 9.75f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.tabPage3.Location = new Point(4, 22);
      this.tabPage3.Name = "tabPage3";
      this.tabPage3.Size = new Size(220, 353);
      this.tabPage3.TabIndex = 2;
      this.tabPage3.Text = "tabPage3";
      this.labelHK.AutoSize = true;
      this.labelHK.Font = new Font("Caviar Dreams", 9.75f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.labelHK.ForeColor = System.Drawing.Color.Lime;
      this.labelHK.Location = new Point(41, 240);
      this.labelHK.Name = "labelHK";
      this.labelHK.Size = new Size(56, 17);
      this.labelHK.TabIndex = 3;
      this.labelHK.Text = "Hotkeys";
      this.panelHK.BorderStyle = BorderStyle.FixedSingle;
      this.panelHK.Controls.Add((Control) this.checkBoxHK);
      this.panelHK.Font = new Font("Caviar Dreams", 9.75f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.panelHK.Location = new Point(15, 239);
      this.panelHK.Name = "panelHK";
      this.panelHK.Size = new Size(20, 20);
      this.panelHK.TabIndex = 4;
      this.checkBoxHK.BackColor = System.Drawing.Color.FromArgb(50, 50, 50);
      this.checkBoxHK.FlatAppearance.BorderSize = 0;
      this.checkBoxHK.FlatStyle = FlatStyle.Flat;
      this.checkBoxHK.Location = new Point(1, 1);
      this.checkBoxHK.Name = "checkBoxHK";
      this.checkBoxHK.Size = new Size(16, 16);
      this.checkBoxHK.TabIndex = 0;
      this.checkBoxHK.TabStop = false;
      this.checkBoxHK.UseVisualStyleBackColor = false;
      this.checkBoxHK.Click += new EventHandler(this.checkBoxHK_Click);
      this.labelTM.AutoSize = true;
      this.labelTM.Font = new Font("Caviar Dreams", 9.75f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.labelTM.ForeColor = System.Drawing.Color.Lime;
      this.labelTM.Location = new Point(41, 199);
      this.labelTM.Name = "labelTM";
      this.labelTM.Size = new Size(67, 17);
      this.labelTM.TabIndex = 1;
      this.labelTM.Text = "Top Most";
      this.panelTM.BorderStyle = BorderStyle.FixedSingle;
      this.panelTM.Controls.Add((Control) this.checkBoxTM);
      this.panelTM.Font = new Font("Caviar Dreams", 9.75f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.panelTM.Location = new Point(15, 198);
      this.panelTM.Name = "panelTM";
      this.panelTM.Size = new Size(20, 20);
      this.panelTM.TabIndex = 2;
      this.checkBoxTM.BackColor = System.Drawing.Color.FromArgb(50, 50, 50);
      this.checkBoxTM.FlatAppearance.BorderSize = 0;
      this.checkBoxTM.FlatStyle = FlatStyle.Flat;
      this.checkBoxTM.Location = new Point(1, 1);
      this.checkBoxTM.Name = "checkBoxTM";
      this.checkBoxTM.Size = new Size(16, 16);
      this.checkBoxTM.TabIndex = 0;
      this.checkBoxTM.TabStop = false;
      this.checkBoxTM.UseVisualStyleBackColor = false;
      this.checkBoxTM.Click += new EventHandler(this.CheckBoxTM_Click);
      this.labelSMC.AutoSize = true;
      this.labelSMC.Font = new Font("Caviar Dreams", 9.75f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.labelSMC.ForeColor = System.Drawing.Color.Lime;
      this.labelSMC.Location = new Point(41, 158);
      this.labelSMC.Name = "labelSMC";
      this.labelSMC.Size = new Size(117, 17);
      this.labelSMC.TabIndex = 0;
      this.labelSMC.Text = "Show Mini Control";
      this.panelSMC.BorderStyle = BorderStyle.FixedSingle;
      this.panelSMC.Controls.Add((Control) this.checkBoxSMC);
      this.panelSMC.Font = new Font("Caviar Dreams", 9.75f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.panelSMC.Location = new Point(15, 157);
      this.panelSMC.Name = "panelSMC";
      this.panelSMC.Size = new Size(20, 20);
      this.panelSMC.TabIndex = 0;
      this.checkBoxSMC.BackColor = System.Drawing.Color.FromArgb(50, 50, 50);
      this.checkBoxSMC.FlatAppearance.BorderSize = 0;
      this.checkBoxSMC.FlatStyle = FlatStyle.Flat;
      this.checkBoxSMC.Location = new Point(1, 1);
      this.checkBoxSMC.Name = "checkBoxSMC";
      this.checkBoxSMC.Size = new Size(16, 16);
      this.checkBoxSMC.TabIndex = 0;
      this.checkBoxSMC.TabStop = false;
      this.checkBoxSMC.UseVisualStyleBackColor = false;
      this.checkBoxSMC.Click += new EventHandler(this.CheckBoxSMC_Click);
      this.panelTrackBar.Controls.Add((Control) this.TrackBarSlider);
      this.panelTrackBar.Controls.Add((Control) this.panelTrackBar2);
      this.panelTrackBar.Font = new Font("Caviar Dreams", 9.75f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.panelTrackBar.Location = new Point(13, 39);
      this.panelTrackBar.Name = "panelTrackBar";
      this.panelTrackBar.Size = new Size(160, 20);
      this.panelTrackBar.TabIndex = 0;
      this.TrackBarSlider.BackColor = System.Drawing.Color.Lime;
      this.TrackBarSlider.FlatAppearance.BorderSize = 0;
      this.TrackBarSlider.FlatStyle = FlatStyle.Flat;
      this.TrackBarSlider.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.TrackBarSlider.ForeColor = System.Drawing.Color.Black;
      this.TrackBarSlider.Location = new Point(0, 0);
      this.TrackBarSlider.Name = "TrackBarSlider";
      this.TrackBarSlider.Size = new Size(10, 20);
      this.TrackBarSlider.TabIndex = 0;
      this.TrackBarSlider.TabStop = false;
      this.TrackBarSlider.TextAlign = ContentAlignment.BottomLeft;
      this.TrackBarSlider.UseVisualStyleBackColor = false;
      this.TrackBarSlider.MouseDown += new MouseEventHandler(this.TrackBarSlider_MouseDown);
      this.TrackBarSlider.MouseMove += new MouseEventHandler(this.TrackBarSlider_MouseMove);
      this.TrackBarSlider.MouseUp += new MouseEventHandler(this.TrackBarSlider_MouseUp);
      this.panelTrackBar2.BackColor = System.Drawing.Color.FromArgb(50, 50, 50);
      this.panelTrackBar2.Location = new Point(1, 7);
      this.panelTrackBar2.Name = "panelTrackBar2";
      this.panelTrackBar2.Size = new Size(160, 5);
      this.panelTrackBar2.TabIndex = 0;
      this.comboBoxColor.BackColor = System.Drawing.Color.FromArgb(10, 10, 10);
      this.comboBoxColor.DropDownStyle = ComboBoxStyle.DropDownList;
      this.comboBoxColor.Font = new Font("Caviar Dreams", 9.75f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.comboBoxColor.ForeColor = System.Drawing.Color.Lime;
      this.comboBoxColor.FormattingEnabled = true;
      this.comboBoxColor.ItemHeight = 17;
      this.comboBoxColor.Items.AddRange(new object[4]
      {
        (object) "FrenzyMode 1x",
        (object) "FrenzyMode 2x",
        (object) "FrenzyMode 3x",
        (object) "FrenzyMode 4x"
      });
      this.comboBoxColor.Location = new Point(13, 106);
      this.comboBoxColor.Name = "comboBoxColor";
      this.comboBoxColor.Size = new Size(160, 25);
      this.comboBoxColor.TabIndex = 0;
      this.comboBoxColor.TabStop = false;
      this.comboBoxColor.SelectedIndexChanged += new EventHandler(this.ComboBox1_SelectedIndexChanged);
      this.labelFC.AutoSize = true;
      this.labelFC.Font = new Font("Caviar Dreams", 9.75f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.labelFC.ForeColor = System.Drawing.Color.Lime;
      this.labelFC.Location = new Point(10, 77);
      this.labelFC.Name = "labelFC";
      this.labelFC.Size = new Size(48, 17);
      this.labelFC.TabIndex = 0;
      this.labelFC.Text = "Color :";
      this.labelCI.AutoSize = true;
      this.labelCI.Font = new Font("Caviar Dreams", 9.75f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.labelCI.ForeColor = System.Drawing.Color.Lime;
      this.labelCI.Location = new Point(10, 10);
      this.labelCI.Name = "labelCI";
      this.labelCI.Size = new Size(124, 17);
      this.labelCI.TabIndex = 0;
      this.labelCI.Text = "Click Interval : 200";
      this.buttonAbout.BackColor = System.Drawing.Color.Lime;
      this.buttonAbout.FlatAppearance.BorderSize = 0;
      this.buttonAbout.FlatStyle = FlatStyle.Flat;
      this.buttonAbout.Font = new Font("Caviar Dreams", 9.75f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.buttonAbout.ForeColor = System.Drawing.Color.Black;
      this.buttonAbout.Location = new Point(10, 287);
      this.buttonAbout.Name = "buttonAbout";
      this.buttonAbout.Size = new Size(200, 50);
      this.buttonAbout.TabIndex = 0;
      this.buttonAbout.TabStop = false;
      this.buttonAbout.Text = "About";
      this.buttonAbout.TextAlign = ContentAlignment.BottomLeft;
      this.buttonAbout.UseVisualStyleBackColor = false;
      this.buttonAbout.Click += new EventHandler(this.ButtonAbout_Click);
      this.labelLogo.AutoSize = true;
      this.labelLogo.Font = new Font("Caviar Dreams", 20.25f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.labelLogo.ForeColor = System.Drawing.Color.Lime;
      this.labelLogo.Location = new Point(20, 20);
      this.labelLogo.Name = "labelLogo";
      this.labelLogo.Size = new Size(155, 34);
      this.labelLogo.TabIndex = 0;
      this.labelLogo.Text = "Zuga Beta";
      this.labelLogo.MouseDown += new MouseEventHandler(this.Label1_MouseDown);
      this.labelLogo.MouseMove += new MouseEventHandler(this.Label1_MouseMove);
      this.labelLogo.MouseUp += new MouseEventHandler(this.Label1_MouseUp);
      this.FrenzyMode.Tick += new EventHandler(this.FrenzyMode_Tick);
      this.label1.AutoSize = true;
      this.label1.Font = new Font("Microsoft Sans Serif", 48f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.label1.ForeColor = SystemColors.ActiveCaption;
      this.label1.Location = new Point(248, 121);
      this.label1.Name = "label1";
      this.label1.Size = new Size(71, 73);
      this.label1.TabIndex = 5;
      this.label1.Text = "Z";
      this.label2.AutoSize = true;
      this.label2.Font = new Font("Microsoft Sans Serif", 48f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.label2.ForeColor = SystemColors.Desktop;
      this.label2.Location = new Point(248, 176);
      this.label2.Name = "label2";
      this.label2.Size = new Size(78, 73);
      this.label2.TabIndex = 6;
      this.label2.Text = "U";
      this.label3.AutoSize = true;
      this.label3.Font = new Font("Microsoft Sans Serif", 48f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.label3.ForeColor = System.Drawing.Color.FromArgb(192, 0, 192);
      this.label3.Location = new Point(248, 239);
      this.label3.Name = "label3";
      this.label3.Size = new Size(82, 73);
      this.label3.TabIndex = 7;
      this.label3.Text = "G";
      this.label4.AutoSize = true;
      this.label4.Font = new Font("Microsoft Sans Serif", 48f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.label4.ForeColor = System.Drawing.Color.FromArgb((int) byte.MaxValue, 128, 0);
      this.label4.Location = new Point(251, 299);
      this.label4.Name = "label4";
      this.label4.Size = new Size(75, 73);
      this.label4.TabIndex = 8;
      this.label4.Text = "A";
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.BackColor = System.Drawing.Color.Lime;
      this.ClientSize = new Size(388, 509);
      this.Controls.Add((Control) this.panelForm);
      this.FormBorderStyle = FormBorderStyle.None;
      this.Icon = (Icon) componentResourceManager.GetObject("$this.Icon");
      this.Name = nameof (MainForm);
      this.StartPosition = FormStartPosition.CenterScreen;
      this.Text = "GTBit Beta";
      this.FormClosing += new FormClosingEventHandler(this.Form1_FormClosing);
      this.Load += new EventHandler(this.Form1_Load);
      this.panelForm.ResumeLayout(false);
      this.panelForm.PerformLayout();
      this.TabSelector.ResumeLayout(false);
      this.panelTabControl.ResumeLayout(false);
      this.tabControl1.ResumeLayout(false);
      this.tabPage1.ResumeLayout(false);
      this.panelWL.ResumeLayout(false);
      this.panelWLH.ResumeLayout(false);
      this.panelWLH.PerformLayout();
      this.Menu1.ResumeLayout(false);
      this.tabPage2.ResumeLayout(false);
      this.panelML.ResumeLayout(false);
      this.panelMLH.ResumeLayout(false);
      this.panelMLH.PerformLayout();
      this.Menu2.ResumeLayout(false);
      this.tabPage3.ResumeLayout(false);
      this.tabPage3.PerformLayout();
      this.panelHK.ResumeLayout(false);
      this.panelTM.ResumeLayout(false);
      this.panelSMC.ResumeLayout(false);
      this.panelTrackBar.ResumeLayout(false);
      this.ResumeLayout(false);
    }

    private delegate ListView.ListViewItemCollection GetItems(ListView listview);
  }
}
