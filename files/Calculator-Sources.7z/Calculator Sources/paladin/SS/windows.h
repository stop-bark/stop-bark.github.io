#pragma once
struct IUnknown;
#define WIN32_LEAN_AND_MEAN
#include <Windows.h>
